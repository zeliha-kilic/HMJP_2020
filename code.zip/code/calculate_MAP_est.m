function MAP = calculate_MAP_est(t_t,d,t_f,t_s,mean_st,P,IT,Q,params,TCM)

%% Part1 - Contribution from the likelihood 

log_ld_s_k      = nan(length(t_t),1);

clear means_s_temp log_ld_s_k

    tStart = tic;
    
    means_s_temp        = reshape(mean_st(t_s),1,1,length(t_s)); 
    log_ld_s_k          = -0.5*params.prec*sum((sum(means_s_temp.*t_f,3)-params.obs').^2);
    
    tElapsed            = toc(tStart);
    
%     tStart_2 = tic;
% 
%     for k=1:length(t_t)
%         
%     means_s_temp        = repmat(reshape(params.mean_st(t_s),1,1,length(t_s)),1,1,1);
%     log_ld_s_k_1        = -0.5*params.prec*sum((sum(means_s_temp.*t_f,3)-params.obs').^2);
% 
%     end
%     
%     tElapsed_2 = toc(tStart_2);


    MAP_1               = log_ld_s_k;
        
%% Part2 - Contribution from the state transitions 
    
    logDiag             = logical(diag(ones(params.M,1)));
    P(logDiag )         = [1;1];
    MAP_2               = sum(sum(TCM(1:2,:).*log(P),2));
 


%% Part3 - Contribution from the holding time
    
    Q_d                = -diag(Q);

    MAP_3              = -sum( d./(Q_d(t_s) + log( Q_d(t_s) ) ) );
    
    
%% Part4 - Contribution from the initial state transition

    MAP_4              = sum( TCM(end,:).*log(IT) );
    
%% Part5 - Contribution from the embeded chain matrix

    MAP_5              = sum( sum( (1/1-1)*log(P+eps) ) );

%% Part6 - Contribution from the initial transition probbaility matrix

    MAP_6              = sum( sum( (params.alpha/params.M-1)*log(IT) ) );


%% Part7 - Contribution coming from teh escape rates

    MAP_7              = sum( (params.eta/2-1)*log(Q_d) - params.eta*params.beta*Q_d/2 );
    
%% Part8 - Contribution coming from the emission rates

    MAP_8              = sum( -(params.phi/2)*(mean_st-params.kappa).^2);
      
%% FINAL MAP
MAP = MAP_1 +MAP_2 +MAP_3 + MAP_4 +MAP_5 +MAP_6 +MAP_7+MAP_8;


