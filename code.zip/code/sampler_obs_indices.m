function [idx,n_idx,group_obs,group_st] = sampler_obs_indices(t_t,params)

% l for observations
% k for panels
% n for times
% j for the groups
% after additon of virtual jumps are added
% distribution of all times indices over observation windows
idx           = cell(1,length(params.obs));
obs_left      = params.t_left;
obs_right     = params.t_right;

for k = 1:length(t_t)
    if ~(abs(k-length(t_t))<eps)
        for l=1:length(params.obs)    
            %%% ----CASE2------
            if  t_t(k)<obs_left(l)&&t_t(k+1)<obs_right(l)&& t_t(k+1)>obs_left(l)
            
            idx{l} = [idx{l};k];
        
            %%% ----CASE3------
            elseif  t_t(k)>obs_left(l)&&t_t(k+1)>obs_right(l)&&t_t(k)<obs_right(l)
            idx{l} = [idx{l};k];
       
            %%% ----CASE4------
            elseif t_t(k)<obs_left(l) && t_t(k+1)>obs_right(l)
            idx{l} = [idx{l};k];

            %%% ----CASE5------
            elseif t_t(k)>obs_left(l)&&t_t(k+1)<obs_right(l)
            idx{l} = [idx{l};k];       
            end

        end 
    else
        for l=1:length(params.obs)    
            if  t_t(k)<obs_left(l) && params.T_f>obs_right(l)
            idx{l} = [idx{l};k];
        
        %%% ----CASE2------
            elseif  t_t(k)>obs_left(l)&& params.T_f>obs_right(l)&& t_t(k)<obs_right(l)
            idx{l} = [idx{l};k];

              
            end

        end 
    end
end

%% List of all_times that do not fall in any of the observation windows



for l =1:length(obs_left)
    if isempty(idx{l})
    	keyboard
    end
end

n_idx = nan(length(obs_left),2);

for l =1:length(obs_left)
    n_idx(l,:) = [idx{l}(1) idx{l}(end)];
end
 
 uu = 0;
 
%% Grouping of the states and the observations 

group_obs{1} = 1;
group_st{1}  = idx{1};
k            = 1;

for l=1:length(idx)-1
    
[~,indx] = ismember(idx{l},idx{l+1});

    if any(indx)
        group_obs{k} = [group_obs{k};l+1];
        group_st{k}  = unique([group_st{k};idx{l+1}]);
    else
        k            = k+1;
        group_obs{k} = l+1;
        group_st{k}  = idx{l+1};
    end    
    
end




% %%
%  %% Finding the repeated trajectories
%  rep = [];
%  
%  for l = 1:length(idx)
%      rep = [rep idx{l}'];
%  end
% %  
% vv      = sum(bsxfun(@eq,rep,rep'),1);
% ttt     = [rep;vv];
% tttt    = unique(ttt.','rows').';
% 
 uu_1  = 0;


