function [t_t,t_s] = sampler_naive_gibbs(t_t,t_s,mean_st,IT,B,t_f,idx,params)


%% -------------------------ALL PANELS----------------------------------
% k is for panels

%% WHICH OBSERVATION WINDOW DOES CONTAIN THE k-th HOLDING STATE (t_k-t_k+1) ?


for k = 1:length(t_t)%randperm(length(t_t)) 

    if abs(k-1)<eps          
        P_in       = IT';     %column matrix     
    else              
        P_in       = B(t_s(k-1),:)';
    end
    
    if abs(k-length(t_t))>eps                        
        P_out      = B(:,t_s(k+1));         
    else              
        P_out      = ones(params.M,1);
    end
   
%          mean_s_temp     = repmat(params.mean_st(t_s)',params.M,1);
%          mean_s_temp(:,k)= params.mean_st(1:1:params.M)';
%          log_ld_s        = -0.5*params.prec*sum(((mean_s_temp*reshape(t_f,length(params.obs),length(t_s))')'-params.obs').^2);
    
    means_s_temp        = repmat(reshape(mean_st(t_s),1,1,length(t_s)),1,params.M,1); % obs*1*length(t_t)
    means_s_temp(1,:,k) = mean_st((1:1:params.M));                                    % only the k th step,no Markovianity
    log_ld_s            = -0.5*params.prec*sum((sum(means_s_temp.*t_f,3)-params.obs').^2);   % 1 by 3
    
%     keyboard
    

    t_s(k)              = gumble_sample( log_ld_s'+log(P_in)+log(P_out));

 
end





uu= 9;
 
% for k = randperm(length(t_t)) 
%     
%     if abs(k-1)<eps
%        
%         t_s(1)  =  gumble_sample(log(IT') +log(B(:,t_s(2))));
%        
%     elseif abs(k-length(t_t))>eps
%         fl =false ;
%         for m=1:length(params.obs)
%             if any( abs(k-idx{m})<eps )
%             fl = true;
%             break
%             end
%         end
% 
% %         ind_obs = find(abs(params.t_left- t_t(k+1))>eps('single') & abs(params.t_right-t_t(k))>eps('single') & params.t_left < t_t(k+1) & params.t_right > t_t(k));
% 
%         if fl
%                    
%             % this gives the full list of 
%             % segment indices falling in the 
%             % m-th observation window
%             % this is required for the likelihood \
%             if isempty(t_s( idx{m}))
%             keyboard
%             end
%                             
%             s_obs       = repmat(t_s( idx{m})',params.M,1); %3 by 3
%             if isempty( s_obs(:,abs( idx{m}'- k) < eps ) )
%             keyboard
%             end
%                   
%             s_obs(:,abs( idx{m}'- k) < eps )  = (1:1:params.M)'; 
%         
%             mean_s_obs  =  params.mean_st(s_obs); %3 by 3
%          
%             ave_mean_s  =  ( 1/sum(t_d( idx{m})) )*(mean_s_obs*t_d( idx{m} ));
%              
%             ld_s        =  -(0.5)*params.prec*(params.obs(m) - ave_mean_s).^2;
% %             keyboard
%             ld_s        =   ld_s + log(B(t_s(k-1),:)') + log(B(:,t_s(k+1)));
%                 
%             t_s(k)      =   gumble_sample(ld_s);
%         
%         
%         else
%         
%             ld_s        =  log(B(t_s(k-1),:)') + log(B(:,t_s(k+1)));
%         
%             t_s(k)     =  gumble_sample(ld_s);
%         end
% 
% 
% clear idx_obs
% 
% 
% %% --------------------------LAST PANEL-NO OBS------------------------------------
% %     elseif abs(k-length(t_s))<eps  %k-th panel
%     else   %k-th panel
% 
% %         ind_obs_l = find(abs(params.t_left- params.T_f)>eps('single') & abs(params.t_right-t_t(k))>eps('single') & params.t_left < params.T_f & params.t_right > t_t(k));
% % last right window is the final time    
% %     
% %         if ~isempty(ind_obs_l)
% %            
% %             idx_obs          = idx{ind_obs_l}; % this gives the full list of 
% %                                            % segment indices falling in the 
% %                                            % m-th observation window
% %                                            % this is required for the
% %                                            % likelihood   
% %             obs_mean         = params.obs(ind_obs_l);
% %                  
% %             s_obs            = repmat(t_s(idx_obs)',params.M,1); %3 by 3
% %         
% %             s_obs(:,abs(idx_obs'- k) < eps) = (1:1:params.M)'; 
% %         
% %             mean_s_obs       = params.mean_st(s_obs); %3 by 3
% %           
% %             ave_mean_s       = ( 1/sum(t_d(idx_obs)) )*(mean_s_obs*t_d(idx_obs));
% %         % 3 by 1
% %         
% %             if ~iscolumn(ave_mean_s)
% %             keyboard
% %             end
% %         
% %             if ~isequal(length(obs_mean),1)
% %             keyboard
% %             end
% %         
% %             ld_s             = -(0.5)*params.prec*(obs_mean - ave_mean_s).^2;
% %         
% %             if isrow(ld_s)
% %             keyboard
% %             end
% %         
% %             ld_s             =  ld_s + (log(B(t_s(k-1),:))');
% %                 
% %             t_s(k)          =  gumble_sample(ld_s);
% %         
% %         
% %         else
% %         
%             ld_s             =  log(B(t_s(k-1),:))';
%                 
%             t_s(k)           =  gumble_sample(ld_s);
%         
%         
% %         end
%    end
% end
%     
%      
