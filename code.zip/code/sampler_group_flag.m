function [flag] = sampler_group_flag(group_st,~)
%% Finding out whether we do FFBS or Naive

flag_group = ones(1,length(group_st));

for j = 1:length(group_st)
    if length(group_st{j})>3
        flag_group(j) = 1;
    else
        flag_group(j) = 0;
    end
end

if any(flag_group)
    flag = 1; %NAIVE
else
    flag = 0; %FFBS
end

   

        