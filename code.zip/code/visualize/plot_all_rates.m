%% Load the Data
%% This function plots all rates NOT during the chain runtime 

addpath('fig')

figure('Units','inch','Position',[-2 -2 10 11])

 
set(gcf,'color','w')
clf
movegui(gcf,'center')



cd   '/home/zkilic/Dropbox (ASU)/zeliha_presselab/MCMC_new/template_all_tags/data'
data_mjp = load('tag_all_2_3551.mat')


%% Visualizing escape rates and Mean Dwell Times
s        = size(data_mjp.Q);

burnin   = 200;

quant_enu = 19;

quant_val = linspace(0,1,2*quant_enu +3);  

d_sample  = 1;

idx       = (burnin:d_sample:s(3));

bin_c     = 35;



Q_mjp   = squeeze(nan(data_mjp.params.M,data_mjp.params.M,length(idx)));

for j=1:length(idx)   
    
Q_mjp(:,:,j) = abs( squeeze(data_mjp.Q(:,:,idx(j))) ) ;

end


Q11_quant    = quantile(Q_mjp(1,1,:),quant_val);

Q12_quant    = quantile(Q_mjp(1,2,:),quant_val);

Q13_quant    = quantile(Q_mjp(1,3,:),quant_val);

Q21_quant    = quantile(Q_mjp(2,1,:),quant_val);

Q22_quant    = quantile(Q_mjp(2,2,:),quant_val);

Q23_quant    = quantile(Q_mjp(2,3,:),quant_val);

Q31_quant    = quantile(Q_mjp(3,1,:),quant_val);

Q32_quant    = quantile(Q_mjp(3,2,:),quant_val);

Q33_quant    = quantile(Q_mjp(3,3,:),quant_val);


title('Escape Rates and Mean Dwell Times')

maxrate = max(max(squeeze([Q_mjp(1,1,1:end) Q_mjp(1,2,1:end) Q_mjp(1,3,1:end) Q_mjp(2,1,1:end)  Q_mjp(2,2,1:end) Q_mjp(2,3,1:end) Q_mjp(3,1,1:end) Q_mjp(3,2,1:end) Q_mjp(3,3,1:end)])));
minrate = min(min(squeeze([Q_mjp(1,1,1:end) Q_mjp(1,2,1:end) Q_mjp(1,3,1:end) Q_mjp(2,1,1:end)  Q_mjp(2,2,1:end) Q_mjp(2,3,1:end) Q_mjp(3,1,1:end) Q_mjp(3,2,1:end) Q_mjp(3,3,1:end)])));

%% True Rate Matrix

true_Q      = data_mjp.params.ground.Q;
       
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Escape Rate (1)

axes11 = subplot(3,3,1)

p1 = histogram(Q_mjp(1,1,:),linspace(min(squeeze(Q_mjp(1,1,:))),max(squeeze(Q_mjp(1,1,:))),bin_c),'normalization','pdf');
yLim = axes11.YLim;

l1 = line(median(Q_mjp(1,1,:)).*[1 1],yLim,'linestyle','--','color','g','linewidth',2)
l2 = line(abs(true_Q(1,1)).*[1 1],yLim,'linestyle',':','color','k','linewidth',2)
for l =1
      f_mjp_1(l)  =  patch([Q11_quant(l,1) Q11_quant(l,1) Q11_quant(l,end) Q11_quant(l,end)],[0 max(p1.Values)+0.05 max(p1.Values)+0.05 0],'m','FaceAlpha',0.07);
      set(f_mjp_1(l),'edgecolor','none')  
end

hold on
ytemp = linspace(minrate,maxrate,100);
escrate_prior1 = plot(ytemp,gampdf(ytemp,data_mjp.params.eta/2,2/(data_mjp.params.eta*data_mjp.params.beta)),'linestyle','--','color','m','linewidth',2)

xlabel('k_{11} (s^{-1})')
xlim([0,5])
ylabel('Post. prob.distr.')
hold off
leg = legend([p1(1) l1(1) l2(1) f_mjp_1(1) escrate_prior1(1)],'Post. prob.distr.','Median post. prob. distr.','Exact rate','95% conf. int.','Prior distr.')   
leg.Location    = 'southoutside';
leg.Orientation = 'horizontal';
leg.Position    = [0.167962688819431 0.938207215678969 0.702954885053042 0.0496688730866702];
legend boxoff;
box off
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Escape Rate (2)

axes12 = subplot(3,3,2)
p1 = histogram(Q_mjp(1,2,:),linspace(min(squeeze(Q_mjp(1,2,:))),max(squeeze(Q_mjp(1,2,:))),bin_c),'normalization','pdf');
yLim = axes12.YLim;

line(median(Q_mjp(1,2,:)).*[1 1],yLim,'linestyle','--','color','g','linewidth',2)
line(abs(true_Q(1,2)).*[1 1],yLim,'linestyle',':','color','k','linewidth',2)
for l =1
      f_mjp_2(l)  =  patch([Q12_quant(l,1) Q12_quant(l,1) Q12_quant(l,end) Q12_quant(l,end)],[0 max(p1.Values)+0.05 max(p1.Values)+0.05 0],'m','FaceAlpha',0.07);
      set(f_mjp_2(l),'edgecolor','none')  
end

xlabel('k_{12} (s^{-1})')
xlim([0,5])
hold off
box off


%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Escape Rate (3)

axes13 = subplot(3,3,3)

p1 = histogram(Q_mjp(1,3,:),linspace(min(squeeze(Q_mjp(1,3,:))),max(squeeze(Q_mjp(1,3,:))),bin_c),'normalization','pdf');
yLim = axes13.YLim;

line(median(Q_mjp(1,3,:)).*[1 1],yLim,'linestyle','--','color','g','linewidth',2)
line(abs(true_Q(1,3)).*[1 1],yLim,'linestyle',':','color','k','linewidth',2)
for l =1
      f_mjp_3(l)  =  patch([Q13_quant(l,1) Q13_quant(l,1) Q13_quant(l,end) Q13_quant(l,end)],[0 max(p1.Values)+0.05 max(p1.Values)+0.05 0],'m','FaceAlpha',0.07);
      set(f_mjp_3(l),'edgecolor','none')  
end

xlabel('k_{13} (s^{-1})')
xlim([0 5])
hold off
box off
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Escape Rate (4)


axes21 = subplot(3,3,4)
p1 = histogram(Q_mjp(2,1,:),linspace(min(squeeze(Q_mjp(2,1,:))),max(squeeze(Q_mjp(2,1,:))),bin_c),'normalization','pdf');
yLim = axes21.YLim;

line(median(Q_mjp(2,1,:)).*[1 1],yLim,'linestyle','--','color','g','linewidth',2)
line(abs(true_Q(2,1)).*[1 1],yLim,'linestyle',':','color','k','linewidth',2)
for l =1
      f_mjp_4(l)  =  patch([Q21_quant(l,1) Q21_quant(l,1) Q21_quant(l,end) Q21_quant(l,end)],[0 max(p1.Values)+0.05 max(p1.Values)+0.05 0],'m','FaceAlpha',0.07);
      set(f_mjp_4(l),'edgecolor','none')  
end

xlabel('k_{21} (s^{-1})')
xlim([0 10])
ylabel('Post. prob. distr.')
hold off
box off

%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Escape Rate (5)


axes22 = subplot(3,3,5)

p1 = histogram(Q_mjp(2,2,:),linspace(min(squeeze(Q_mjp(2,2,:))),max(squeeze(Q_mjp(2,2,:))),bin_c),'normalization','pdf');
yLim = axes22.YLim;

line(median(Q_mjp(2,2,:)).*[1 1],yLim,'linestyle','--','color','g','linewidth',2)
line(abs(true_Q(2,2)).*[1 1],yLim,'linestyle',':','color','k','linewidth',2)
for l =1
      f_mjp_5(l)  =  patch([Q22_quant(l,1) Q22_quant(l,1) Q22_quant(l,end) Q22_quant(l,end)],[0 max(p1.Values)+0.05 max(p1.Values)+0.05 0],'m','FaceAlpha',0.07);
      set(f_mjp_5(l),'edgecolor','none')  
end

hold on
ytemp = linspace(minrate,maxrate,100);
escrate_prior1 = plot(ytemp,gampdf(ytemp,data_mjp.params.eta/2,2/(data_mjp.params.eta*data_mjp.params.beta)),'linestyle','--','color','m','linewidth',2)

xlabel('k_{22} (s^{-1})')
xlim([0 14])
hold off
box off
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Escape Rate (6)

axes23 = subplot(3,3,6)
p1 = histogram(Q_mjp(2,3,:),linspace(min(squeeze(Q_mjp(2,3,:))),max(squeeze(Q_mjp(2,3,:))),bin_c),'normalization','pdf');
yLim = axes23.YLim;

line(median(Q_mjp(2,3,:)).*[1 1],yLim,'linestyle','--','color','g','linewidth',2)
line(abs(true_Q(2,3)).*[1 1],yLim,'linestyle',':','color','k','linewidth',2)
for l =1
      f_mjp_6(l)  =  patch([Q23_quant(l,1) Q23_quant(l,1) Q23_quant(l,end) Q23_quant(l,end)],[0 max(p1.Values)+0.05 max(p1.Values)+0.05 0],'m','FaceAlpha',0.07);
      set(f_mjp_6(l),'edgecolor','none')  
end

xlabel('k_{23} (s^{-1})')
xlim([0 10])
hold off
box off



%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Escape Rate (7)


axes31 = subplot(3,3,7)
p1 = histogram(Q_mjp(3,1,:),linspace(min(squeeze(Q_mjp(3,1,:))),max(squeeze(Q_mjp(3,1,:))),bin_c),'normalization','pdf');
yLim = axes31.YLim;

line(median(Q_mjp(3,1,:)).*[1 1],yLim,'linestyle','--','color','g','linewidth',2)
line(abs(true_Q(3,1)).*[1 1],yLim,'linestyle',':','color','k','linewidth',2)
for l =1
      f_mjp_7(l)  =  patch([Q31_quant(l,1) Q31_quant(l,1) Q31_quant(l,end) Q31_quant(l,end)],[0 max(p1.Values)+0.05 max(p1.Values)+0.05 0],'m','FaceAlpha',0.07);
      set(f_mjp_7(l),'edgecolor','none')  
end

xlabel('k_{31} (s^{-1})')
ylabel('Post. prob. distr.')
hold off
box off


%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Escape Rate (8)


axes32 = subplot(3,3,8)
p1 = histogram(Q_mjp(3,2,:),linspace(min(squeeze(Q_mjp(3,2,:))),max(squeeze(Q_mjp(3,2,:))),bin_c),'normalization','pdf');
yLim = axes32.YLim;

line(median(Q_mjp(3,2,:)).*[1 1],yLim,'linestyle','--','color','g','linewidth',2)
line(abs(true_Q(3,2)).*[1 1],yLim,'linestyle',':','color','k','linewidth',2)
for l =1
      f_mjp_8(l)  =  patch([Q32_quant(l,1) Q32_quant(l,1) Q32_quant(l,end) Q32_quant(l,end)],[0 max(p1.Values)+0.05 max(p1.Values)+0.05 0],'m','FaceAlpha',0.07);
      set(f_mjp_8(l),'edgecolor','none')  
end

xlabel('k_{32} (s^{-1})')
hold off
box off


%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Escape Rate (9)


axes33 = subplot(3,3,9)
p1 = histogram(Q_mjp(3,3,:),linspace(min(squeeze(Q_mjp(3,3,:))),max(squeeze(Q_mjp(3,3,:))),bin_c),'normalization','pdf');
yLim = axes33.YLim;

line(median(Q_mjp(3,3,:)).*[1 1],yLim,'linestyle','--','color','g','linewidth',2)
line(abs(true_Q(3,3)).*[1 1],yLim,'linestyle',':','color','k','linewidth',2)
for l =1
      f_mjp_9(l)  =  patch([Q33_quant(l,1) Q33_quant(l,1) Q33_quant(l,end) Q33_quant(l,end)],[0 max(p1.Values)+0.05 max(p1.Values)+0.05 0],'m','FaceAlpha',0.07);
      set(f_mjp_9(l),'edgecolor','none')  
end

hold on
ytemp = linspace(minrate,maxrate,100);
escrate_prior1 = plot(ytemp,gampdf(ytemp,data_mjp.params.eta/2,2/(data_mjp.params.eta*data_mjp.params.beta)),'linestyle','--','color','m','linewidth',2)

xlabel('k_{33} (s^{-1})')
hold off
box off

%% -----SAVE FIGURE--------------------------------------
%  fig  = Figures;
%  fig.Name = 'self-transition probs';
% 
% % sizes
% fig.Units = 'centimeters';
% width  =30;
% height =24;
% fig.Position(3:4) = [width height];
%  
% set(fig,'defaultLineLineWidth',1.5);   % set the default line width to lw
% set(fig,'defaultLineMarkerSize',8); % set the default line marker size to msz
% 
% 
% % Set the default Size for display
% defpos = get(fig,'defaultFigurePosition');
% set(fig,'defaultFigurePosition', [defpos(1) defpos(2) width*300, height*300]);
% 
% % Set the defaults for saving/printing to a file
% set(fig,'defaultFigureInvertHardcopy','on'); % This is the default anyway
% set(fig,'defaultFigurePaperUnits','centimeters'); % This is the default anyway
% defsize = get(gcf, 'PaperSize');
% left = (defsize(1)- width+0.2)/2;
% bottom = (defsize(2)- height)/2;
% defsize = [left, bottom, width, height];
% set(fig, 'defaultFigurePaperPosition', defsize);
%   
%   
% print('all_rates.pdf','-dpdf');

