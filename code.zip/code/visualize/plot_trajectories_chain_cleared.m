%% Load the Data
%  load('')

addpath('fig')

figure('Units','inch','Position',[0 0 10 11])

 
set(gcf,'color','w')
clf
movegui(gcf,'center')

% set(gcf,'windowstyle','docked')

chain        = load('sim_data_every_low_prec_59836.mat');

m_length     = size(chain.Q);
chain.length = m_length(3);

idx          = (10:500:chain.length);

%% OBSERVATION WINDOWS

yl   = [chain.params.mean_st(1)-1  chain.params.mean_st(end)+1];

for j=1:length(chain.params.t_left)
    
obs_w = [chain.params.t_left(j) chain.params.t_right(j)];

hold on

p111 = patch([obs_w fliplr(obs_w)], [yl(1) yl(1) yl(2) yl(2)], [1 1 0.84],'EdgeColor','none');

end

%% PLOT MULTIPLE TRAJECTORIES

for  j= 1:length(idx)
    
p11 = plot_one_traj(chain.t_t{idx(j)},chain.t_s{idx(j)},[   0.854901960784314   0.968627450980392   0.968627450980392
]);

hold on

end

hold off

%% PLOT OBSERVATION VALUES

p1      = line([chain.params.t_left(j) chain.params.t_right(j)],[chain.params.obs(j) chain.params.obs(j)],'color','k','LineWidth',5);
hold on 
for j=2:length(chain.params.obs)
    
line([chain.params.t_left(j) chain.params.t_right(j)],[chain.params.obs(j) chain.params.obs(j)],'color','k','LineWidth',5);

end
hold off
%% PLOT TRUE TRAJECTORY

t_true      = [chain.params.ground.t_t;chain.params.T_f];
s_true      = [chain.params.ground.t_s;chain.params.ground.t_s(end)]; 

[tx_true,sx_true] = stairs(t_true,s_true);
l2 = line([chain.params.T_i,chain.params.T_f],chain.params.mean_st([1;2;3]).*[1 1],'linestyle',':','color', [0.501960784313725   0.501960784313725   0.501960784313725],'LineWidth',1);
l1 = line(tx_true,chain.params.mean_st(sx_true),'linewidth',1.5,'linestyle','-','color',   [0.501960784313725   0.501960784313725   0.501960784313725]);
line(chain.params.T_i.*[1 1],[chain.params.mean_st(1)-1,chain.params.mean_st(end)+1],'linestyle','-','color','k','linewidth',1);
line(chain.params.T_f.*[1 1],[chain.params.mean_st(1)-1,chain.params.mean_st(end)+1],'linestyle','-','color','k','linewidth',1);
line([chain.params.T_i,chain.params.T_f],0.*[1 1],'linestyle','-','color', 'k','LineWidth',0.5);
leg = legend([p111(1) p11(1) p1(1) l1(1) l2(1)],'Observation windows','Posterior traj. distr.','Observation','True traj.','Physical states');
leg.Location    = 'northoutside';
leg.Orientation = 'horizontal';
% leg.Position    = [0.167962688819431 0.938207215678969 0.702954885053042 0.0496688730866702];
legend boxoff;



xlim_0   =  chain.params.T_i - 0.05*(chain.params.T_f-chain.params.T_i);
xlim_end =  chain.params.T_f + 0.05*(chain.params.T_f-chain.params.T_i) ;


xlim([xlim_0 xlim_end]);
ylim([0,6]);

xlabel('Time (s)');
ylabel('Space (nm)');

yticks([1 2 3 4 5 ]);
yticklabels({'','','','',''});


text(-0.75,chain.params.mean_st(1),'\mu_{\sigma_1}','color', [0.501960784313725   0.501960784313725   0.501960784313725]);
text(-0.75,chain.params.mean_st(2),'\mu_{\sigma_2}','color', [0.501960784313725   0.501960784313725   0.501960784313725]);
text(-0.75,chain.params.mean_st(3),'\mu_{\sigma_3}','color', [0.501960784313725   0.501960784313725   0.501960784313725]);

%  fig  = Figures;
%  fig.Name = 'trajs';
% 
% % sizes
% fig.Units = 'centimeters';
% width  =25;
% height =12;
% fig.Position(3:4) = [width height];
%  
% set(fig,'defaultLineLineWidth',1.5);   % set the default line width to lw
% set(fig,'defaultLineMarkerSize',8); % set the default line marker size to msz
% 
% 
% % Set the default Size for display
% defpos = get(fig,'defaultFigurePosition');
% set(fig,'defaultFigurePosition', [defpos(1) defpos(2) width*300, height*300]);
% 
% % Set the defaults for saving/printing to a file
% set(fig,'defaultFigureInvertHardcopy','on'); % This is the default anyway
% set(fig,'defaultFigurePaperUnits','centimeters'); % This is the default anyway
% defsize = get(gcf, 'PaperSize');
% left = (defsize(1)- width+0.2)/2;
% bottom = (defsize(2)- height)/2;
% defsize = [left, bottom, width, height];
% set(fig, 'defaultFigurePaperPosition', defsize);
%   
%   
% print('trajpdf.pdf','-dpdf');
% 







