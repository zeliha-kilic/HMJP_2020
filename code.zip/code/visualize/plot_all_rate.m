%% Load the Data
clear all
close all
clc
load('sim_data_every_low_prec_59836.mat')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%This function is dedicated for the rate matrix besides the                 %
%prior distirbutions for the escape rates                                   %
%                                                                           %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%% Visualizing escape rates and Mean Dwell Times
s     = length(Q(1,1,:))


for j=1000:s(1)
    lambda11(j) = abs(Q(1,1,j));
end
for j=1000:s(1)
    lambda12(j) = Q(1,2,j);
end
for j=1000:s(1)
    lambda13(j) = Q(1,3,j);
end
for j=1000:s(1)
    lambda21(j) = Q(2,1,j);
end
for j=1000:s(1)
    lambda22(j) = abs(Q(2,2,j));
end
for j=1000:s(1)
    lambda23(j) = Q(2,3,j);
end
for j=1000:s(1)
    lambda31(j) = Q(3,1,j);
end
for j=1000:s(1)
    lambda32(j) = Q(3,2,j);
end
for j=1000:s(1)
    lambda33(j) = abs(Q(3,3,j));
end
figure(58)
title('Escape Rates and Mean Dwell Times')

maxrate = max([lambda11(1001:end) lambda12(1001:end) lambda13(1001:end) lambda21(1001:end)  lambda22(1001:end) lambda23(1001:end) lambda31(1001:end) lambda32(1001:end) lambda33(1001:end)]);
minrate = min([lambda11(1001:end) lambda12(1001:end) lambda13(1001:end) lambda21(1001:end)  lambda22(1001:end) lambda23(1001:end) lambda31(1001:end) lambda32(1001:end) lambda33(1001:end)]);

%% True Rate Matrix

true_Q      = params.ground.Q;
       
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Escape Rate (1)

axes11 = subplot(3,3,1)
hold on
title('Individual Rates')
% keyboard
histogram(abs(lambda11(1001:end)),linspace(minrate,maxrate,100),'normalization','pdf');
yLim = axes11.YLim;
line(median(lambda11(1001:end)).*[1 1],yLim,'linestyle','--','color','g','linewidth',2)
line(abs(true_Q(1,1)).*[1 1],yLim,'linestyle',':','color','k','linewidth',2)
ytemp = linspace(minrate,maxrate,100);
escrate_prior1 = plot(ytemp,gampdf(ytemp,params.eta/2,2/(params.eta*params.beta)),'linestyle','--','color','m','linewidth',2)
xlabel('k_{11} (1/sec)')
xlim([0,10])
ylabel('PDF')
hold off
legend('learned','median','true')   


%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Escape Rate (2)

axes12 = subplot(3,3,2)
hold on
title('Individual Rates')
histogram(lambda12(1001:end),linspace(minrate,maxrate,100),'normalization','pdf');
yLim = axes12.YLim;
line(median(lambda12(1001:end)).*[1 1],yLim,'linestyle','--','color','g','linewidth',2)
line(abs(true_Q(1,2)).*[1 1],yLim,'linestyle',':','color','k','linewidth',2)
% ytemp = linspace(0.1,5,100);
% escrate_prior1 = plot(ytemp,gampdf(ytemp,4/2,2/(4*1)),'linestyle','--','color','m','linewidth',2)
xlabel('k_{12}(1/sec) ')
xlim([0,10])
ylabel('PDF')
hold off
legend('learned','median','true')


%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Escape Rate (3)

axes13 = subplot(3,3,3)
hold on
title('Individual Rates')
histogram(lambda13(1001:end),linspace(minrate,maxrate,100),'normalization','pdf');
line(median(lambda13(1001:end)).*[1 1],axes13.YLim,'linestyle','--','color','g','linewidth',2)
line((abs(true_Q(1,3)))*[1 1],axes13.YLim,'linestyle',':','color','k','linewidth',2)
legend('learned','median','true')
xlabel('k_{13} (1/sec) ')
set(axes12,'XScale','lin')
ylabel('PDF')
hold off


%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Escape Rate (4)


axes21 = subplot(3,3,4)
histogram(lambda21(1001:end),linspace(minrate,maxrate,100),'normalization','pdf');
line(median(lambda21(1001:end)).*[1 1],axes21.YLim,'linestyle','--','color','g','linewidth',2)
line(abs(true_Q(2,1)).*[1 1],axes21.YLim,'linestyle',':','color','k','linewidth',2)
% ytemp = linspace(0.1,5,100);
% hold on
% escrate_prior2 = plot(ytemp,gampdf(ytemp,4/2,2/(4*1)),'linestyle','--','color','m','linewidth',2)
xlabel('k_{21}(1/sec) ')
ylabel('PDF')
legend('learned','median','true')


%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Escape Rate (5)


axes22 = subplot(3,3,5)
histogram(lambda22(1001:end),linspace(minrate,maxrate,100),'normalization','pdf');
line(median(lambda22(1001:end)).*[1 1],axes22.YLim,'linestyle','--','color','g','linewidth',2)
line(abs(true_Q(2,2)).*[1 1],axes22.YLim,'linestyle',':','color','k','linewidth',2)
set(axes22,'XScale','lin')
ytemp = linspace(minrate,maxrate,100);
hold on
escrate_prior2 = plot(ytemp,gampdf(ytemp,params.eta/2,2/(params.eta*params.beta)),'linestyle','--','color','m','linewidth',2)
xlabel('k_{22}(1/sec)')
ylabel('PDF')
hold off
legend('learned','median','true','location','NE')



%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Escape Rate (6)



axes23 = subplot(3,3,6)
histogram(lambda23(1001:end),linspace(minrate,maxrate,100),'normalization','pdf');
line(median(lambda23(1001:end)).*[1 1],axes23.YLim,'linestyle','--','color','g','linewidth',2)
line(((((abs(true_Q(2,3)))))).*[1 1],axes23.YLim,'linestyle',':','color','k','linewidth',2)
set(axes22,'XScale','lin')

xlabel('k_{23}(1/sec)')
ylabel('PDF')
hold off
legend('learned','median','true','location','NE')



%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Escape Rate (7)


axes31 = subplot(3,3,7)

histogram(lambda31(1001:end),linspace(minrate,maxrate,100),'normalization','pdf');

line( median( lambda31(1001:end) ).*[1 1],axes31.YLim,'linestyle','--','color','g','linewidth',2)
line( abs( true_Q(3,1) ).*[1 1],axes31.YLim,'linestyle',':','color','k','linewidth',2)

xlabel('k_{31}(1/sec)')
ylabel('PDF')
hold off
legend('learned','median','true','location','NW')

%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Escape Rate (8)


axes32 = subplot(3,3,8)
histogram(lambda32(1001:end),linspace(minrate,maxrate,100),'normalization','pdf');
line(median(lambda32(1001:end)).*[1 1],axes32.YLim,'linestyle','--','color','g','linewidth',2)
line(((abs(true_Q(3,2)))).*[1 1],axes32.YLim,'linestyle',':','color','k','linewidth',2)
set(axes32,'XScale','lin')

xlabel('k_{32}(1/sec)')
ylabel('PDF')
legend('learned','median','true','location','NE')


%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Escape Rate (9)


axes33 = subplot(3,3,9)
histogram(lambda33(1001:end),linspace(minrate,maxrate,100),'normalization','pdf');
line(median(lambda33(1001:end)).*[1 1],axes33.YLim,'linestyle','--','color','g','linewidth',2)
line(((abs(true_Q(3,3)))).*[1 1],axes33.YLim,'linestyle',':','color','k','linewidth',2)
set(axes33,'XScale','lin')
ytemp = linspace(minrate,maxrate,100);
hold on
escrate_prior = plot(ytemp,gampdf(ytemp,params.eta/2,2/(params.eta*params.beta)),'linestyle','--','color','m','linewidth',2)
xlabel('k_{33}(1/sec)')
ylabel('PDF')
legend('learned','median','true','location','NE')
