%% Load the Data
% load('')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%This function is dedicated for the rate matrix besides the                 %
%prior distirbutions for the escape rates                                   %
%                                                                           %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

load('sim_data_all')

%% Ground Truth

true_Q             = - [   -3   0.9  2.1 ;...
                          3.8  -6.1  2.3;...
                         3.94  2.06 -6 ];
figure(55)


title('Escape Rates and Mean Dwell Times')

axes11  = subplot(6,3,1);
axes12  = subplot(6,3,2);
axes13  = subplot(6,3,3);
axes21  = subplot(6,3,4);
axes22  = subplot(6,3,5);
axes23  = subplot(6,3,6);
axes31  = subplot(6,3,7);
axes32  = subplot(6,3,8);
axes33  = subplot(6,3,9);
axes41  = subplot(6,3,10);
axes42  = subplot(6,3,11);
axes43  = subplot(6,3,12);
axes51  = subplot(6,3,13);
axes52  = subplot(6,3,14);
axes53  = subplot(6,3,15);
axes61  = subplot(6,3,16);
axes62  = subplot(6,3,17);
axes63  = subplot(6,3,18);


Q = chain.Q;


%% Visualizing escape rates and Mean Dwell Times
s     = size(Q);

lambda11 = nan(s(3)-1000,1);
lambda12 = nan(s(3)-1000,1);
lambda13 = nan(s(3)-1000,1);
lambda21 = nan(s(3)-1000,1);
lambda22 = nan(s(3)-1000,1);
lambda23 = nan(s(3)-1000,1);
lambda31 = nan(s(3)-1000,1);
lambda32 = nan(s(3)-1000,1);
lambda33 = nan(s(3)-1000,1);


for j=1001:s(3)
    lambda11(j-1000) = abs(Q(1,1,j));
end
for j=1001:s(3)
    lambda12(j-1000) = Q(1,2,j);
end
for j=1001:s(3)
    lambda13(j-1000) = Q(1,3,j);
end
for j=1001:s(3)
    lambda21(j-1000) = Q(2,1,j);
end
for j=1001:s(3)
    lambda22(j-1000) = abs(Q(2,2,j));
end
for j=1001:s(3)
    lambda23(j-1000) = Q(2,3,j);
end
for j=1001:s(3)
    lambda31(j-1000) = Q(3,1,j);
end
for j=1001:s(3)
    lambda32(j-1000) = Q(3,2,j);
end
for j=1001:s(3)
    lambda33(j-1000) = abs(Q(3,3,j));
end


maxrate = max([lambda11(1:end) lambda12(1:end) lambda13(1:end) lambda21(1:end)  lambda22(1:end) lambda23(1:end) lambda31(1:end) lambda32(1:end) lambda33(1:end)]);
minrate = min([lambda11(1:end) lambda12(1:end) lambda13(1:end) lambda21(1:end)  lambda22(1:end) lambda23(1:end) lambda31(1:end) lambda32(1:end) lambda33(1:end)]);


%% Escape Rate (1)

axes(axes11)
hold on
title('Individual Rates')
% keyboard
histogram(abs(lambda11(1:end)),linspace(minrate,maxrate,100),'normalization','pdf');
yLim = axes11.YLim;
line(median(lambda11(1:end)).*[1 1],yLim,'linestyle','--','color','g','linewidth',2)
line(abs(true_Q(1,1)).*[1 1],yLim,'linestyle',':','color','k','linewidth',2)
ytemp = linspace(0.1,5,100);
 plot(ytemp,gampdf(ytemp,4/2,2/(4*1)),'linestyle','--','color','m','linewidth',2);
xlabel('k_{11} (1/sec)')
xlim([0,10])
ylabel('PDF')
hold off
legend('learned','median','true')   


%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Escape Rate (2)

axes(axes12)
hold on
title('Individual Rates')
histogram(lambda12(1 :end),linspace(minrate,maxrate,100),'normalization','pdf');
yLim = axes12.YLim;
line(median(lambda12(1 :end)).*[1 1],yLim,'linestyle','--','color','g','linewidth',2)
line(abs(true_Q(1,2)).*[1 1],yLim,'linestyle',':','color','k','linewidth',2)
% ytemp = linspace(0.1,5,100);
% escrate_prior1 = plot(ytemp,gampdf(ytemp,4/2,2/(4*1)),'linestyle','--','color','m','linewidth',2)
xlabel('k_{12}(1/sec) ')
xlim([0,10])
ylabel('PDF')
hold off
legend('learned','median','true')


%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Escape Rate (3)

axes(axes13)
hold on
title('Individual Rates')
histogram(lambda13(1 :end),linspace(minrate,maxrate,100),'normalization','pdf');
line(median(lambda13(1 :end)).*[1 1],axes13.YLim,'linestyle','--','color','g','linewidth',2)
line((abs(true_Q(1,3)))*[1 1],axes13.YLim,'linestyle',':','color','k','linewidth',2)
legend('learned','median','true')
xlabel('k_{13} (1/sec) ')
set(axes13,'XScale','lin')
ylabel('PDF')
hold off


%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Escape Rate (4)


axes(axes21)
histogram(lambda21(1 :end),linspace(minrate,maxrate,100),'normalization','pdf');
line(median(lambda21(1 :end)).*[1 1],axes21.YLim,'linestyle','--','color','g','linewidth',2)
line(abs(true_Q(2,1)).*[1 1],axes21.YLim,'linestyle',':','color','k','linewidth',2)
% ytemp = linspace(0.1,5,100);
% hold on
% escrate_prior2 = plot(ytemp,gampdf(ytemp,4/2,2/(4*1)),'linestyle','--','color','m','linewidth',2)
xlabel('k_{21}(1/sec) ')
ylabel('PDF')
legend('learned','median','true')


%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Escape Rate (5)


axes(axes22)
histogram(lambda22(1 :end),linspace(minrate,maxrate,100),'normalization','pdf');
line(median(lambda22(1 :end)).*[1 1],axes22.YLim,'linestyle','--','color','g','linewidth',2)
line(abs(true_Q(2,2)).*[1 1],axes22.YLim,'linestyle',':','color','k','linewidth',2)
set(axes22,'XScale','lin')
ytemp = linspace(0.1,5,100);
hold on
plot(ytemp,gampdf(ytemp,4/2,2/(4*1)),'linestyle','--','color','m','linewidth',2);
xlabel('k_{22}(1/sec)')
ylabel('PDF')
hold off
legend('learned','median','true','location','NE')



%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Escape Rate (6)



axes(axes23)
histogram(lambda23(1 :end),linspace(minrate,maxrate,100),'normalization','pdf');
line(median(lambda23(1 :end)).*[1 1],axes23.YLim,'linestyle','--','color','g','linewidth',2)
line(((((abs(true_Q(2,3)))))).*[1 1],axes23.YLim,'linestyle',':','color','k','linewidth',2)
set(axes23,'XScale','lin')

xlabel('k_{23}(1/sec)')
ylabel('PDF')
hold off
legend('learned','median','true','location','NE')



%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Escape Rate (7)


axes(axes31)

histogram(lambda31(1 :end),linspace(minrate,maxrate,100),'normalization','pdf');

line( median( lambda31(1 :end) ).*[1 1],axes31.YLim,'linestyle','--','color','g','linewidth',2)
line( abs( true_Q(3,1) ).*[1 1],axes31.YLim,'linestyle',':','color','k','linewidth',2)

xlabel('k_{31}(1/sec)')
ylabel('PDF')
hold off
legend('learned','median','true','location','NW')

%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Escape Rate (8)


axes(axes32)
histogram(lambda32(1 :end),linspace(minrate,maxrate,100),'normalization','pdf');
line(median(lambda32(1 :end)).*[1 1],axes32.YLim,'linestyle','--','color','g','linewidth',2)
line(((abs(true_Q(3,2)))).*[1 1],axes32.YLim,'linestyle',':','color','k','linewidth',2)
set(axes32,'XScale','lin')

xlabel('k_{32}(1/sec)')
ylabel('PDF')
legend('learned','median','true','location','NE')


%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Escape Rate (9)


axes(axes33)

histogram(lambda33(1 :end),linspace(minrate,maxrate,100),'normalization','pdf');
line(median(lambda33(1 :end)).*[1 1],axes33.YLim,'linestyle','--','color','g','linewidth',2)
line(((abs(true_Q(3,3)))).*[1 1],axes33.YLim,'linestyle',':','color','k','linewidth',2)
set(axes33,'XScale','lin')
ytemp = linspace(0.1,5,100);
hold on
plot(ytemp,gampdf(ytemp,4/2,2/(4*1)),'linestyle','--','color','m','linewidth',2);
xlabel('k_{33}(1/sec)')
ylabel('PDF')
legend('learned','median','true','location','NE')


%% ------------------SECOND DATA SET---------------------------------------------------
clear chain
clear ground  Q  s lambda11 lambda12 lambda13 lambda21 lambda22 lambda23 lambda31 lambda32 lambda33 chain


load('sim_data_10XX')

Q = chain.Q;
s     = size(Q);
lambda11 = nan(1130,1);
lambda12 = nan(1130,1);
lambda13 = nan(1130,1);
lambda21 = nan(1130,1);
lambda22 = nan(1130,1);
lambda23 = nan(1130,1);
lambda31 = nan(1130,1);
lambda32 = nan(1130,1);
lambda33 = nan(1130,1);

for j=1001:2230
    lambda11(j-1000) = abs(Q(1,1,j));
end
for j=1001:2230
    lambda12(j-1000) = Q(1,2,j);
end
for j=1001:2230
    lambda13(j-1000) = Q(1,3,j);
end
for j=1001:2230
    lambda21(j-1000) = Q(2,1,j);
end
for j=1001:2230
    lambda22(j-1000) = abs(Q(2,2,j));
end
for j=1001:2230
    lambda23(j-1000) = Q(2,3,j);
end
for j=1001:2230
    lambda31(j-1000) = Q(3,1,j);
end
for j=1001:2230
    lambda32(j-1000) = Q(3,2,j);
end
for j=1001:2230
    lambda33(j-1000) = abs(Q(3,3,j));
end


maxrate = max([lambda11(1:end) lambda12(1:end) lambda13(1:end) lambda21(1:end)  lambda22(1:end) lambda23(1:end) lambda31(1:end) lambda32(1:end) lambda33(1:end)]);
minrate = min([lambda11(1:end) lambda12(1:end) lambda13(1:end) lambda21(1:end)  lambda22(1:end) lambda23(1:end) lambda31(1:end) lambda32(1:end) lambda33(1:end)]);


%% Escape Rate (1)

axes(axes41)
hold on
title('Individual Rates 10X')
% keyboard
histogram(abs(lambda11(1:end)),linspace(minrate,maxrate,100),'normalization','pdf');
yLim = axes41.YLim;
line(median(lambda11(1:end)).*[1 1],yLim,'linestyle','--','color','g','linewidth',2)
line(abs(true_Q(1,1)).*[1 1],yLim,'linestyle',':','color','k','linewidth',2)
ytemp = linspace(0.1,5,100);
escrate_prior1 = plot(ytemp,gampdf(ytemp,4/2,2/(4*1)),'linestyle','--','color','m','linewidth',2);
xlabel('k_{11} (1/sec)')
xlim([0,10])
ylabel('PDF')
hold off
legend('learned','median','true')   


%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Escape Rate (2)

axes(axes42)
hold on
title('Individual Rates 10X')
histogram(lambda12(1:end),linspace(minrate,maxrate,100),'normalization','pdf');
yLim = axes42.YLim;
line(median(lambda12(1:end)).*[1 1],yLim,'linestyle','--','color','g','linewidth',2)
line(abs(true_Q(1,2)).*[1 1],yLim,'linestyle',':','color','k','linewidth',2)
% ytemp = linspace(0.1,5,100);
% escrate_prior1 = plot(ytemp,gampdf(ytemp,4/2,2/(4*1)),'linestyle','--','color','m','linewidth',2)
xlabel('k_{12}(1/sec) ')
xlim([0,10])
ylabel('PDF')
hold off
legend('learned','median','true')


%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Escape Rate (3)

axes(axes43)
hold on
title('Individual Rates 10X')
histogram(lambda13(1:end),linspace(minrate,maxrate,100),'normalization','pdf');
line(median(lambda13(1:end)).*[1 1],axes43.YLim,'linestyle','--','color','g','linewidth',2)
line((abs(true_Q(1,3)))*[1 1],axes43.YLim,'linestyle',':','color','k','linewidth',2)
legend('learned','median','true')
xlabel('k_{13} (1/sec) ')
set(axes43,'XScale','lin')
ylabel('PDF')
hold off


%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Escape Rate (4)


axes(axes51)
histogram(lambda21(1:end),linspace(minrate,maxrate,100),'normalization','pdf');
line(median(lambda21(1:end)).*[1 1],axes51.YLim,'linestyle','--','color','g','linewidth',2)
line(abs(true_Q(2,1)).*[1 1],axes51.YLim,'linestyle',':','color','k','linewidth',2)
% ytemp = linspace(0.1,5,100);
% hold on
% escrate_prior2 = plot(ytemp,gampdf(ytemp,4/2,2/(4*1)),'linestyle','--','color','m','linewidth',2)
xlabel('k_{21}(1/sec) ')
ylabel('PDF')
legend('learned','median','true')


%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Escape Rate (5)


axes(axes52)
histogram(lambda22(1:end),linspace(minrate,maxrate,100),'normalization','pdf');
line(median(lambda22(1:end)).*[1 1],axes52.YLim,'linestyle','--','color','g','linewidth',2)
line(abs(true_Q(2,2)).*[1 1],axes52.YLim,'linestyle',':','color','k','linewidth',2)
set(axes52,'XScale','lin')
ytemp = linspace(0.1,5,100);
hold on
escrate_prior2 = plot(ytemp,gampdf(ytemp,4/2,2/(4*1)),'linestyle','--','color','m','linewidth',2);
xlabel('k_{22}(1/sec)')
ylabel('PDF')
hold off
legend('learned','median','true','location','NE')



%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Escape Rate (6)



axes(axes53)
histogram(lambda23(1:end),linspace(minrate,maxrate,100),'normalization','pdf');
line(median(lambda23(1:end)).*[1 1],axes53.YLim,'linestyle','--','color','g','linewidth',2)
line(((((abs(true_Q(2,3)))))).*[1 1],axes53.YLim,'linestyle',':','color','k','linewidth',2)
set(axes53,'XScale','lin')

xlabel('k_{23}(1/sec)')
ylabel('PDF')
hold off
legend('learned','median','true','location','NE')



%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Escape Rate (7)


axes(axes61)

histogram(lambda31(1:end),linspace(minrate,maxrate,100),'normalization','pdf');

line( median( lambda31(1:end) ).*[1 1],axes61.YLim,'linestyle','--','color','g','linewidth',2)
line( abs( true_Q(3,1) ).*[1 1],axes61.YLim,'linestyle',':','color','k','linewidth',2)

xlabel('k_{31}(1/sec)')
ylabel('PDF')
hold off
legend('learned','median','true','location','NW')

%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Escape Rate (8)


axes(axes62)
histogram(lambda32(1:end),linspace(minrate,maxrate,100),'normalization','pdf');
line(median(lambda32(1:end)).*[1 1],axes62.YLim,'linestyle','--','color','g','linewidth',2)
line(((abs(true_Q(3,2)))).*[1 1],axes62.YLim,'linestyle',':','color','k','linewidth',2)
set(axes62,'XScale','lin')

xlabel('k_{32}(1/sec)')
ylabel('PDF')
legend('learned','median','true','location','NE')


%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Escape Rate (9)


axes(axes63)
histogram(lambda33(1:end),linspace(minrate,maxrate,100),'normalization','pdf');
line(median(lambda33(1:end)).*[1 1],axes63.YLim,'linestyle','--','color','g','linewidth',2)
line(((abs(true_Q(3,3)))).*[1 1],axes63.YLim,'linestyle',':','color','k','linewidth',2)
set(axes63,'XScale','lin')
ytemp = linspace(0.1,5,100);
hold on
escrate_prior = plot(ytemp,gampdf(ytemp,4/2,2/(4*1)),'linestyle','--','color','m','linewidth',2);
xlabel('k_{33}(1/sec)')
ylabel('PDF')
legend('learned','median','true','location','NE')

