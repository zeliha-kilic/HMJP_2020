%% Load the Data
%  load('')
Figures = figure(55)


idx = (1:500:chain.length);


%% OBSERVATION WINDOWS

yl = [chain.mean_st(1)-1  chain.mean_st(end)+1];

for j=1:length(chain.params.t_left)
    
obs_w = [chain.params.t_left(j) chain.params.t_right(j)];

hold on

p111 = patch([obs_w fliplr(obs_w)], [yl(1) yl(1) yl(2) yl(2)], [0.5 0.6 0.5],'EdgeColor','none');

end

%% PLOT MULTIPLE TRAJECTORIES
for  j= 1:length(idx)
    
p11 = plot_one_traj(chain.t_t{idx(j)},chain.t_s{idx(j)},[   0.854901960784314   0.968627450980392   0.968627450980392
],chain.mean_st(:,j));

hold on

end

hold off

%% PLOT OBSERVATION VALUES

p1      = line([chain.params.t_left(j) chain.params.t_right(j)],[chain.params.obs(j) chain.params.obs(j)],'color','k','LineWidth',5);
hold on 
for j=2:length(chain.params.obs)
    
line([chain.params.t_left(j) chain.params.t_right(j)],[chain.params.obs(j) chain.params.obs(j)],'color','k','LineWidth',5);

end
hold off
%% PLOT TRUE TRAJECTORY

t_true      = [chain.params.ground.t_t;chain.params.T_f];
s_true      = [chain.params.ground.t_s;chain.params.ground.t_s(end)]; 

[tx_true,sx_true] = stairs(t_true,s_true);

l1 = line(tx_true,chain.params.ground.mean_st(sx_true),'linewidth',1.5,'linestyle','--','color',   [0.501960784313725   0.501960784313725   0.501960784313725]);
l2 = line([chain.params.T_i,chain.params.T_f],chain.mean_st([1;2],idx(end))'.*[1 ;1],'linestyle','--','color',[0.2 0.8 0.8],'LineWidth',1);
line(chain.params.T_i.*[1 1],[chain.mean_st(1)-1,chain.params.ground.mean_st(end)+1],'linestyle','--','color','k','linewidth',2);
line(chain.params.T_f.*[1 1],[chain.mean_st(1)-1,chain.params.ground.mean_st(end)+1],'linestyle','--','color','k','linewidth',2);
leg = legend([p111(1) p11(1) p1(1) l1(1) l2(1)],'Observation windows','Posterior traj. distr.','Observation','True traj.','Physical states');
leg.Location    = 'southoutside';
leg.Orientation = 'horizontal';
% leg.Position    = [0.167962688819431 0.938207215678969 0.702954885053042 0.0496688730866702];
legend boxoff;



xlim_0   =  chain.params.T_i - 0.05*(chain.params.T_f-chain.params.T_i);
xlim_end =  chain.params.T_f + 0.05*(chain.params.T_f-chain.params.T_i) ;


xlim([xlim_0 xlim_end]);
ylim([0,max(chain.mean_st([1;2],idx(end)))+0.5]);

xlabel('Time (s)');
ylabel('Space (nm)');

yticks([1 2 3 4 5 6 7]);
yticklabels({'1','','','','7'});


% text(-0.75,chain.mean_st(1),'\mu_{\sigma_1}','color',[0.2 0.8 0.8]);
% text(-0.75,chain.mean_st(2),'\mu_{\sigma_2}','color',[0.2 0.8 0.8]);
% 




