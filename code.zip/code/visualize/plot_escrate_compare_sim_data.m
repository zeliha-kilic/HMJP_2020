%% Load the Data
clf

load('sim_data_all')

%% Ground Truth

Q_g             = - [-3     0.9  2.1 ;...
                   3.8  -6.1  2.3;...
                   3.94  2.06 -6 ];
figure(55)

title('Escape Rates and Mean Dwell Times')

axes11  = subplot(6,2,1);
axes12  = subplot(6,2,2);
axes21  = subplot(6,2,3);
axes22  = subplot(6,2,4);
axes31  = subplot(6,2,5);
axes32  = subplot(6,2,6);
axes41  = subplot(6,2,7);
axes42  = subplot(6,2,8);
axes51  = subplot(6,2,9);
axes52  = subplot(6,2,10);
axes61  = subplot(6,2,11);
axes62  = subplot(6,2,12);

%% ---------------FIRST DATA SET -----------------------------------------

s     = size(chain.Q);
lambda1 = nan(length(s(3))-1000,1);
lambda2 = nan(length(s(3))-1000,1);
lambda3 = nan(length(s(3))-1000,1);


for j=1001:s(3)
    lambda1(j-1000) = -chain.Q(1,1,j);
end
for j=1001:s(3)
    lambda2(j-1000) = -chain.Q(2,2,j);
end
for j=1001:s(3)
    lambda3(j-1000) = -chain.Q(3,3,j);
end




maxrate = max( max([lambda1 lambda2 lambda3]) );
minrate = min( min([lambda1 lambda2 lambda3]) );

axes(axes11)
hold on
title('Escape Rates')
histogram(lambda1,linspace(0,maxrate,100),'normalization','pdf');
yLim = axes11.YLim;
line(median(lambda1).*[1 1],yLim,'linestyle','--','color','g','linewidth',2)
line(Q_g(1,1).*[1 1],yLim,'linestyle',':','color','b','linewidth',2)
ytemp = linspace(0.1,5,100);
escrate_prior1 = plot(ytemp,gampdf(ytemp,4/2,2/(4*1)),'linestyle','--','color','m','linewidth',2);
xlabel('\lambda_1')
xlim([0,10])
ylabel('PDF')
hold off
legend('learned','median','true','prior','location','NE')

axes(axes12)
hold on
title('Mean Dwell Times')
histogram(1./lambda1,linspace(0,1/minrate,100),'normalization','pdf');
line(median(1./lambda1).*[1 1],axes12.YLim,'linestyle','--','color','g','linewidth',2)
line((1/Q_g(1,1))*[1 1],axes12.YLim,'linestyle',':','color','b','linewidth',2)

xlabel('1/\lambda_1')
set(axes12,'XScale','lin')
ylabel('PDF')
hold off
legend('learned','median','true','location','NW')

%%%%%%%
axes(axes21)
histogram(lambda2,linspace(0,maxrate,100),'normalization','pdf');
line(median(lambda2).*[1 1],axes21.YLim,'linestyle','--','color','g','linewidth',2)
line(Q_g(2,2).*[1 1],axes21.YLim,'linestyle',':','color','b','linewidth',2)
ytemp = linspace(0.1,5,100);
hold on
escrate_prior2 = plot(ytemp,gampdf(ytemp,4/2,2/(4*1)),'linestyle','--','color','m','linewidth',2);
xlabel('\lambda_2')
ylabel('PDF')
legend('learned','median','true','prior','location','NW')

axes(axes22)
histogram(1./lambda2,linspace(0,1/minrate,100),'normalization','pdf');
line(median(1./lambda2).*[1 1],axes22.YLim,'linestyle','--','color','g','linewidth',2)
line((1./(Q_g(2,2))).*[1 1],axes22.YLim,'linestyle',':','color','b','linewidth',2)
set(axes22,'XScale','lin')

xlabel('1/\lambda_2')
ylabel('PDF')
hold off
legend('learned','median','true','location','NE')

axes(axes31)
histogram(lambda3,linspace(0,maxrate,100),'normalization','pdf');
line(median(lambda3).*[1 1],axes31.YLim,'linestyle','--','color','g','linewidth',2)
line(Q_g(3,3).*[1 1],axes31.YLim,'linestyle',':','color','b','linewidth',2)
ytemp = linspace(0.1,5,100);
hold on
escrate_prior = plot(ytemp,gampdf(ytemp,4/2,2/(4*1)),'linestyle','--','color','m','linewidth',2);
xlabel('\lambda_3')
ylabel('PDF')
hold off
% legend('learned','median','true','prior','location','NE')

axes(axes32)
histogram(1./lambda3,linspace(0,1/minrate,100),'normalization','pdf');
line(median(1./lambda3).*[1 1],axes32.YLim,'linestyle','--','color','g','linewidth',2)
line(median(1./Q_g(3,3)).*[1 1],axes32.YLim,'linestyle',':','color','b','linewidth',2)
set(axes32,'XScale','lin')

xlabel('1/\lambda_3')
ylabel('PDF')
legend('learned','median','true','location','NE')


%% --------------------------SECOND DATA SET ------------------------------------
clear s lambda1 lambda2 lambda3 

load('sim_data_10XX')

s     = size(chain.Q);

lambda1 = nan(2300-1000,1);
lambda2 = nan(2300-1000,1);
lambda3 = nan(2300-1000,1);

for j=1001:2300
    lambda1(j-1000) = -chain.Q(1,1,j);
end
for j=1001:2300
    lambda2(j-1000) = -chain.Q(2,2,j);
end
for j=1001:2300
    lambda3(j-1000) = -chain.Q(3,3,j);
end



maxrate = max( max([lambda1 lambda2 lambda3]) );
minrate = min( min([lambda1 lambda2 lambda3]) );

axes(axes41)
hold on
title('Escape Rates 10X')
histogram(lambda1,linspace(0,maxrate,100),'normalization','pdf');
yLim = axes41.YLim;
line(median(lambda1).*[1 1],yLim,'linestyle','--','color','g','linewidth',2)
line(Q_g(1,1).*[1 1],yLim,'linestyle',':','color','b','linewidth',2)
ytemp = linspace(0.1,5,100);
escrate_prior1 = plot(ytemp,gampdf(ytemp,4/2,2/(4*1)),'linestyle','--','color','m','linewidth',2);
xlabel('\lambda_1')
xlim([0,10])
ylabel('PDF')
hold off
legend('learned','median','true','prior','location','NE')

axes(axes42)
hold on
title('Mean Dwell Times 10X')
histogram(1./lambda1,linspace(0,1/minrate,100),'normalization','pdf');
line(median(1./lambda1).*[1 1],axes42.YLim,'linestyle','--','color','g','linewidth',2)
line((1/Q_g(1,1))*[1 1],axes42.YLim,'linestyle',':','color','b','linewidth',2)


xlabel('1/\lambda_1')
set(axes42,'XScale','lin')
ylabel('PDF')
hold off
legend('learned','median','true','location','NW')

%%%%%%%
axes(axes51)
histogram(lambda2,linspace(0,maxrate,100),'normalization','pdf');
line(median(lambda2).*[1 1],axes51.YLim,'linestyle','--','color','g','linewidth',2)
line(Q_g(2,2).*[1 1],axes51.YLim,'linestyle',':','color','b','linewidth',2)
ytemp = linspace(0.1,5,100);
hold on
escrate_prior2 = plot(ytemp,gampdf(ytemp,4/2,2/(4*1)),'linestyle','--','color','m','linewidth',2);
xlim([0,10])
xlabel('\lambda_2')
ylabel('PDF')
legend('learned','median','true','prior','location','NW')

axes(axes52)
histogram(1./lambda2,linspace(0,1/minrate,100),'normalization','pdf');
line(median(1./lambda2).*[1 1],axes52.YLim,'linestyle','--','color','g','linewidth',2)
line((1./(Q_g(2,2))).*[1 1],axes52.YLim,'linestyle',':','color','b','linewidth',2)
set(axes52,'XScale','lin')

xlabel('1/\lambda_2')
ylabel('PDF')
hold off
legend('learned','median','true','location','NW')

axes(axes61)
histogram(lambda3,linspace(0,maxrate,100),'normalization','pdf');
line(median(lambda3).*[1 1],axes61.YLim,'linestyle','--','color','g','linewidth',2)
line(Q_g(3,3).*[1 1],axes61.YLim,'linestyle',':','color','b','linewidth',2)
ytemp = linspace(0.1,5,100);
hold on
xlim([0,10])
escrate_prior = plot(ytemp,gampdf(ytemp,4/2,2/(4*1)),'linestyle','--','color','m','linewidth',2);
xlabel('\lambda_3')
ylabel('PDF')
hold off
% legend('learned','median','true','prior','location','NE')

axes(axes62)

histogram(1./lambda3,linspace(0,1/minrate,100),'normalization','pdf');
line(median(1./lambda3).*[1 1],axes62.YLim,'linestyle','--','color','g','linewidth',2)
line(median(1./Q_g(3,3)).*[1 1],axes62.YLim,'linestyle',':','color','b','linewidth',2)
set(axes32,'XScale','lin')

xlabel('1/\lambda_3')
ylabel('PDF')
legend('learned','median','true','location','NE')

