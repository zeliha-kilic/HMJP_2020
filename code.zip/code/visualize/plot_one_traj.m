function p1 = plot_one_traj(t_t,t_s,p_color,mean_st)

[tx,sx] =  stairs(t_t,mean_st(t_s));
sleft   =  nan(length(t_t),1);
tleft   =  nan(length(t_t),1);
for n=1:length(t_t)
    sleft(n) = sx(2*n-1);
    tleft(n) = tx(2*n-1);
end
sright  = nan(length(t_t)-1,1);
tright  = nan(length(t_t)-1,1);
for n=1:length(t_t)-1
    sright(n) = sx(2*n);
    tright(n) = tx(2*n);
end

xlim([-0.1 max(t_t)])

p1      =  plot(tx,sx+(0.05)*randn(1),'color',p_color,...
    'LineWidth',1);

xlabel('Time (s)')
ylabel('Space (nm)')

ylim([0,6])

yticks([1 2  5])

hold off