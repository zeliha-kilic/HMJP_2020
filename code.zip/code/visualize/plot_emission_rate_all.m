%% Load the Data
%  load('')
close all

addpath('fig')

figure('Units','inch','Position',[0 0 3.5 4])

set(gcf,'color','w')

movegui(gcf,'center')

% set(gcf,'windowstyle','docked')
cd ..
cd data
chain        = load('MJP_tag_103.mat');
cd ..
cd visualize

m_length     = size(chain.Q);
chain.length = m_length(3);


idx = (5000:1:chain.length);
chain.i = (1:1:chain.length);


for j=1:chain.params.M
axes1 = subplot(1,2,1);

p1    = plot(chain.i,(chain.mean_st(j,:)),...
    chain.i(idx),(chain.mean_st(j,idx)),'.-','linewidth',1);
hold on
if j-size(chain.params.ground.mean_st,1)<= eps
    hold on
l1    = line(axes1.XLim,chain.params.ground.mean_st(j).*[1 1],'linestyle','-','color','c','LineWidth',3);
end
ylabel(['\mu_{', '1,2,3,4','}(a.u.)']);


axes11 = subplot(1,2,2);
ytemp = logspace(-1,2,100);
histogram((chain.mean_st(j,idx)),ytemp,'normalization','pdf','Orientation','horizontal','Facecolor',get(p1(2),'color'));
hold on
ylim(axes1.YLim);
ytemp = logspace(-1,3,100);
l2 = line(normpdf(ytemp,chain.params.kappa,1/chain.params.phi),ytemp,'linestyle','-','color','m','linewidth',2);
if j-size(chain.params.ground.mean_st,1)<= eps
line([0 .5],chain.params.ground.mean_st(j).*[1 1],'linestyle','-','color','c','LineWidth',2);
end
% xlim([0 0.4])
set(gca,'YScale','log')
end
linkaxes([axes1,axes11],'y')
legg = legend([l1(1) l2(1)],{'{True emis. rate}','{Prior distr.}'},'Orientation','horizontal');
legg.Location = 'northoutside';
legg.NumColumns = 2;

legg.Position = [0.154761904761905,0.947131048387096,0.732142857142857,0.052083333333333];
