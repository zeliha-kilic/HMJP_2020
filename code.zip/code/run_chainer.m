% save_file = [mfilename,'.mat'];
format compact

%% simulate data
tag              = 101;
% [observation,units,ground] = generate_synthetic_data(tag,true);
load('simulated_tag_101_0.09.mat')
%% init chain

opts.obs         = observation.obs;

opts.t_left      = observation.t_left;

opts.t_right     = observation.t_right;

opts.prec        = observation.prec;

opts.units       = units;

opts.M           = 2;

opts.alpha       = 2;
 
opts.beta        = 0.03;

opts.eta         = 4;

opts.kappa       = mean(observation.obs); % mean of the mean_st

opts.phi         = 1; %prec for mean_st

%% ---------DEBUGGING RATES and PROBS

opts.ground.t_t         = ground.traj_t;
opts.ground.t_s         = ground.traj_s;
opts.ground.Q           = ground.Q;
opts.ground.escrate     = -diag(ground.Q)';
opts.ground.mean_state  = ground.mean_state;

opts.T_i                = ground.T_i;
opts.T_f                = ground.T_f;
    
chain_length            = 50;

chain = chainer_main([],0,opts,true,[]);

clear opts


%% expand chain

while true
                     
    chain = chainer_main(chain,chain_length,[],true,true);

    if chain.sizeGB > 1.0
    
    chain = chainer_main(chain,-fix(chain.length/2),[],true,[]);
    
    end
    
    export_chain(chain, 1 , ['MJP_tag_',num2str(tag)]);

end
% save(save_file)
% disp(['SAVED: ', save_file])

