function mean_st = sampler_update_emission(t_s,t_f,mean_st_old,params)
% this function updates the molecule state levels

if isempty(t_s)
    mean_st = nan(params.M,1);
    mean_st = params.alpha + (1/sqrt(params.phi))*randn([params.M,1]);
else
    t_f     = reshape(t_f,length(params.obs),length(t_s));
    mean_st = nan(params.M,1);
    ind_j   = (1:1:params.M);
    for rep_em = 1:15
        for j = 1:params.M
            ind = (t_s == j);
            j_p = ind_j==j;
            ind1= ~(t_s == j);
            num_j = sum(t_f(:,ind),2);
            mean_st(j,1) = (params.prec*sum((params.obs'-(1-num_j)*mean_st_old(ind_j(3-j))).*num_j) + params.alpha*params.phi)/((params.prec*sum(num_j.^2)+params.phi) )+...
                         ( 1/sqrt( (params.prec*sum(num_j.^2)+params.phi) ) )*randn(1);
        end
    end
end
    
    

        
