function export_chain(chain, samp_rate , nameit)


maxsample   = (length(chain.i));
minsample   = 1;
mem         = chain.sizeGB;
params      = chain.params;

for samplenum   = 1:fix(1/samp_rate): maxsample
    
t_s{samplenum,:}         = chain.t_s{samplenum,:};
t_t{samplenum,:}         = chain.t_t{samplenum,:};
IT(samplenum,:)          = chain.IT(samplenum,:);
P(:,:,samplenum)         = chain.P(:,:,samplenum);
Q(:,:,samplenum)         = chain.Q(:,:,samplenum);
mean_st(:,samplenum)     = chain.mean_st(:,samplenum);
MAP(:,samplenum)          = chain.MAP(:,samplenum);

end 

cd '/home/zkilic/project2_revision/data' ;
save([nameit,'.mat'],'mem','params','t_s','t_t','IT','P','Q','mean_st','MAP','-v7.3');
%v7-3 is for data >2gb
disp([nameit,'.mat','--mission_accomplished']);
cd '/home/zkilic/project2_revision' ;
