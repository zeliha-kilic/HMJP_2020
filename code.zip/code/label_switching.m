function chain_sw  = label_switching(chain)

chain_sw.length  = chain.length;
mu               = nan(2,1);
chain_sw.mean_st = nan(2,chain_sw.length);
chain_sw.t_t        = cell(chain_sw.length,1);
chain_sw.t_s        = cell(chain_sw.length,1);
chain_sw.Q          = nan(2,2,chain_sw.length);
for j=1:chain_sw.length
    
    mu  = chain.mean_st(:,j);
    qu  = chain.escrate(j,:);
    
    if (chain.mean_st(1,j)>chain.mean_st(2,j))       
    chain_sw.mean_st(1,j)           = mu(2);
    chain_sw.mean_st(2,j)           = mu(1);
    chain_sw.escrate(1,j)           = qu(2);
    chain_sw.escrate(2,j)           = qu(1);
    idx                             = chain.t_s{j}==1;
    idx_p                           = chain.t_s{j}==2;

    chain.t_s{j}(idx,1)             = 2;
    chain.t_s{j}(idx_p,1)           = 1;
    chain_sw.t_t{j}                 = chain.t_t{j};
    chain_sw.t_s{j}                 = chain.t_s{j};  
    chain_sw.Q(1,2,j)               = chain_sw.escrate(1,j);
    chain_sw.Q(1,1,j)               = -chain_sw.escrate(1,j);
    chain_sw.Q(2,1,j)               = chain_sw.escrate(2,j);
    chain_sw.Q(2,2,j)               = -chain_sw.escrate(2,j);
    else
    chain_sw.t_t{j}                 = chain.t_t{j};
    chain_sw.t_s{j}                 = chain.t_s{j}; 
    chain_sw.mean_st(:,j)           = chain.mean_st(:,j);
    chain_sw.escrate(:,j)           = chain.escrate(j,:);
    chain_sw.Q(1,1,j)               = chain.Q(1,1,j);
    chain_sw.Q(1,2,j)               = chain.Q(1,2,j);
    chain_sw.Q(2,1,j)               = chain.Q(2,1,j);
    chain_sw.Q(2,2,j)               = chain.Q(2,2,j);

    end     

end

    chain_sw.sample = chain.sample;
    chain_sw.sizeGB = chain.sizeGB;
    chain_sw.i      = chain.i;
    chain_sw.IT     = chain.IT;
    chain_sw.params = chain.params;
    




    
    