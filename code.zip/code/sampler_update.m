function sample = sampler_update( sample, params )

%% update counter
sample.i = sample.i + 1;

%% Uniformize
[B_prob,omega]                          = sampler_uniformize(sample.Q,params);

%% Add Virtual Jumps
[sample.t_t, sample.t_s]                = sampler_add_jumps(sample.t_t,sample.t_s,sample.Q,omega,params);

%% Holding Times and Indexes AFTER the Virtual Jumps                           
t_f                                     = sampler_hold_fractions(sample.t_t,params                           );

%% Trajectory sections for each observation window and group information
[idx,~,sample.group_obs,sample.group_st]  = sampler_obs_indices(sample.t_t,params                            );

%% Indices of the observation groups and state groups and the state space sizes for each group
[l_obs,n_st,~]                     = sampler_group_indices(sample.group_obs,sample.group_st                  );
[flag]                             = sampler_group_flag(sample.group_st,n_st                                 );
 P_gr                              = sampler_group_prob(B_prob,sample.IT,sample.group_st,n_st,flag           );
%% Sample New Mean Molecule States
sample.mean_st                     = sampler_update_emission(sample.t_s,t_f,sample.mean_st,params            );

%% Sample New Traj
[sample.t_t,sample.t_s]            = sampler_sample_traj(sample.t_t,sample.t_s,sample.mean_st,sample.group_st,n_st,l_obs,...
                                                         sample.IT,B_prob,P_gr,t_f,idx,params,flag     );
%% Debugging rates and probs
%   sample.t_t                      = params.ground.t_t;
%   sample.t_s                      = params.ground.t_s;

%% Remove Virtual Jumps
[sample.t_t, sample.t_s]           = sampler_drop_jumps(sample.t_t,sample.t_s,params                   );

%% Calculate Holding Times After REMOVING the virtual jumps
t_d                                = sampler_hold_times(sample.t_t,params                              );

%% Transition Counts       
TCM                                = sampler_transit_count(sample.t_t,sample.t_s,params                );

%% Transition Probs
[sample.P,sample.IT]               = sampler_transit_prob(TCM,params                                   );

%% EscRate
sample.escrate                     = sampler_escrate(sample.t_s,TCM,t_d,params                         ); 

%% Rate Matrix
 sample.Q                          = sampler_full_rate(sample.P,sample.escrate,params                  );
 
 t_f                               = sampler_hold_fractions(sample.t_t,params                           );

 sample.MAP =   calculate_MAP_est(sample.t_t,t_d,t_f,sample.t_s,sample.mean_st,sample.P,sample.IT,sample.Q,params,TCM);