function Gim = chainer_visualize(Gim,chain)


%% -------------------------------------------------------------------------
if isempty(Gim)

addpath('visualize')

figure(10)
set(gcf,'windowstyle','docked');


% LABELS AND AXES

t_true      = chain.params.ground.t_t;
s_true      = chain.params.ground.t_s; 

[tx_true,sx_true] = stairs(t_true,s_true);

t_t         =  (chain.sample.t_t);
t_s         =  (chain.sample.t_s);


    if chain.sample.t_t(end) < chain.params.T_f
        chain.sample.t_t = [chain.sample.t_t; chain.params.T_f];
        chain.sample.t_s = [chain.sample.t_s;chain.sample.t_s(end)];
    end
    
    

axes1 = subplot(2,2,[1;3]);
[tx,sx]     =  stairs( chain.sample.t_t,chain.sample.mean_st(chain.sample.t_s) );

Gim.p1 = plot(tx,sx,'-mo','LineWidth',2);
line(chain.params.T_i.*[1 1],[0,max(chain.sample.mean_st(chain.sample.t_s))+0.1],'linestyle','--','color','k','linewidth',2);
line(chain.params.T_f.*[1 1],[0,max(chain.sample.mean_st(chain.sample.t_s))+0.1],'linestyle','--','color','k','linewidth',2);
line(tx_true,chain.params.ground.mean_st(sx_true),'linestyle','-.','color','b')
line([chain.params.T_i,chain.params.T_f],chain.params.ground.mean_st([1;2])'.*[1 ;1],'linestyle','-','color','c','LineWidth',.1);
hold on

    for j=1:length(chain.params.t_left)
    
        line([chain.params.t_left(j) chain.params.t_right(j)],...
            [chain.params.obs(j) chain.params.obs(j)],'color','k','LineWidth',5);

    end
        hold off
        
xlim_0   =  chain.params.T_i - 0.05*(chain.params.T_f-chain.params.T_i);
xlim_end =  chain.params.T_f + 0.05*(chain.params.T_f-chain.params.T_i) ;


xlim([xlim_0 xlim_end]);
ylim([0,2*max(chain.sample.mean_st(chain.sample.t_s))]);

xlabel('Time (s)');
ylabel('Space (nm)');

text(-0.2,1,'\mu_{\sigma_1}','color','cyan');
text(-0.2,5,'\mu_{\sigma_2}','color','cyan');

set(gca);

axes0   = subplot(2,2,[2;4]);
ylimits = axes1.YLim;
yvals   = linspace(ylimits(1),ylimits(end),100);
mean_st_prior = (chain.params.phi/(2*pi))*exp(-(yvals - chain.params.kappa).^2*chain.params.phi/2);
Gim.p0 = plot(mean_st_prior,yvals,'m-');
xlim([0 max(mean_st_prior)])
ylim([yvals(1) yvals(end)])
box on



else

t_t         =  (chain.sample.t_t);
t_s         =  (chain.sample.t_s);


 if chain.sample.t_t(end) < chain.params.T_f
          chain.sample.t_t = [chain.sample.t_t; chain.params.T_f];
          chain.sample.t_s = [chain.sample.t_s;chain.sample.t_s(end)];
 end

[tx,sx]     =  stairs( chain.sample.t_t,chain.sample.mean_st(chain.sample.t_s) );    
    
set(Gim.p1,'XData',tx,'YData',sx);

ylimits = get(gca,'yLim');
axes1.ylim = ylimits;
yvals   = linspace(ylimits(1),ylimits(end),100);
mean_st_prior = (chain.params.phi/(2*pi))*exp(-(yvals - chain.params.kappa).^2*chain.params.phi/2);


        
        
set(Gim.p0,'XData',mean_st_prior,'YData',yvals);

end



drawnow