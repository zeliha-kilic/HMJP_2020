function [t_t,t_s] = sampler_sample_traj(t_t,t_s,mean_st,group_st,n_st,l_obs,IT,B,P_gr,t_f,idx,params,flag)

thresh = 1;   
fl     = false;
for m =1:length(idx)   
     if  (length(idx{m}) >= thresh) 
     fl = true;    
     break    
     end      
end



if any(flag)%fl   
 [t_t,t_s] = sampler_naive_gibbs(t_t,t_s,mean_st,IT,B,t_f,idx,params);    
% else    
% %   keyboard
%  [t_t,t_s] = chainer_FFBS(t_t,t_s,mean_st,t_f,params,P_gr,group_st,n_st,l_obs);
end
% 
% for m = 1:length(idx)
%     
%     if length(idx{m})>=1
% 
%        flag
%         
%        [t_t,t_s] = chainer_naive_gibbs(t_t,t_s,IT,B,t_d,idx,params);
%        
%     else
%         
%        [t_t,t_s] = chainer_FFBS(t_t,t_s,IT,B,t_d,idx,params);
%        
%     end
%     
% end
% 


