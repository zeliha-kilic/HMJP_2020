function [l_obs,n_st,group_M] = sampler_group_indices(group_obs,group_st)

l_obs   = zeros(length(group_obs),2);
n_st    = zeros(length(group_st),2);
group_M = zeros(length(group_st),1);

for k =1:length(group_st)
    
    l_obs(k,:) = [group_obs{k}(1) group_obs{k}(end)]; 
    n_st(k,:)  = [group_st{k}(1) group_st{k}(end)]; 
    group_M(k) = 2^(n_st(k,2)-n_st(k,1)+1);

end





    
