function [observation,units,ground] = generate_synthetic_data_multi(tag,show_demo)

if nargin<1
    show_demo = true;   
    tag       = 1;
end

%% set up-Units

% units
 units.time    = 's';
 units.space   = 'nm';
 
 switch tag
%%%%%%%%%%%%%%%%%%%%%%%%% SHORETER EXPOSURE, 0.09 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                         

     case 1     %FAST
      dt       = 0.1;%100 ms window
     alpha     = 0.9;
      tau_f    = .1;
      Q        =  (1/tau_f)*[-1.2 1.2;
                             1.4 -1.4]; 
     case 4    %SLOWER
      dt       = 0.1;%100 ms window
     alpha     = 0.9;
      tau_f    = .2;
      Q        =  (1/tau_f)*[-1.2 1.2;
                             1.4 -1.4]; 
     case 11    %SLOWER
      dt       = 0.1;%100 ms window
     alpha     = 0.9;
      tau_f    = .8;
      Q        =  (1/tau_f)*[-1.2 1.2;
                             1.4 -1.4];                 
     case 5    %FASTER
      dt       = 0.1;%100 ms window
     alpha     = 0.9;
      tau_f    = 1/12;
      Q        =  (1/tau_f)*[-1.2 1.2;
                             1.4 -1.4];   
     case 6    %FASTER
      dt       = 0.1;%100 ms window
     alpha     = 0.9;
      tau_f    = 1/15;
      Q        =  (1/tau_f)*[-1.2 1.2;
                             1.4 -1.4]; 
%%%%%%%%%%%%%%%%%%%%%%%%% LONGER EXPOSURE, 0.098 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                         
     case 7     %FAST
      dt       = 0.1;%100 ms window
     alpha     = 0.98;
      tau_f    = .1;
      Q        =  (1/tau_f)*[-1.2 1.2;
                             1.4 -1.4]; 
                         
     case 8    %SLOWER
      dt       = 0.1;%100 ms window
     alpha     = 0.98;
      tau_f    = .2;
      Q        =  (1/tau_f)*[-1.2 1.2;
                             1.4 -1.4]; 
     case 9    %FASTER
      dt       = 0.1;%100 ms window
     alpha     = 0.98;
      tau_f    = 1/12;
      Q        =  (1/tau_f)*[-1.2 1.2;
                             1.4 -1.4]; 
     case 10    %FASTER
      dt       = 0.1;%100 ms window
     alpha     = 0.98;
      tau_f    = 1/15;
      Q        =  (1/tau_f)*[-1.2 1.2;
                             1.4 -1.4]; 

     case 13    %SLOWER
      dt       = 0.1;%100 ms window
     alpha     = 0.98;
      tau_f    = .8;
      Q        =  (1/tau_f)*[-1.2 1.2;
                             1.4 -1.4];   
%%%%%%%%%%%%%%%%%%%%%%%%%CHANGED RATE MATRIX %%%%%%%%%%%%%%%%%%%%%%% 
 
     case 61     %FAST
      dt       = 0.1;%100 ms window
     alpha     = 0.9;
      tau_f    = .1;
      Q        =  (1/tau_f)*[-1.1 1.1;
                             1.6 -1.6]; 
     case 31    %SLOWER
      dt       = 0.1;%100 ms window
     alpha     = 0.9;
      tau_f    = .8;
      Q        =  (1/tau_f)*[-1.1 1.1;
                             1.6 -1.6];                 
     case 41    %FASTER
      dt       = 0.1;%100 ms window
     alpha     = 0.9;
      tau_f    = 1/12;
      Q        =  (1/tau_f)*[-1.1 1.1;
                             1.6 -1.6];   
     case 51    %FASTER
      dt       = 0.1;%100 ms window
     alpha     = 0.9;
      tau_f    = 1/15;
      Q        =  (1/tau_f)*[-1.1 1.1;
                             1.6 -1.6];  
     case 71    %FASTER
      dt       = 0.1;%100 ms window
     alpha     = 0.9;
      tau_f    = 1/50;
      Q        =  (1/tau_f)*[-1.1 1.1;
                             1.6 -1.6]; 
     case 91    %FASTER
      dt       = 0.1;%100 ms window
     alpha     = 0.9;
      tau_f    = 1/30;
      Q        =  (1/tau_f)*[-0.2 0.2;
                             1.6 -1.6]; 
     case 21    %FASTER
      dt       = 0.1;%100 ms window
     alpha     = 0.9;
      tau_f    = 1/15;
      Q        = (1/tau_f)*[-0.2 0.2;
                            1.6 -1.6];
                        
     case 81    %SLOWER
      dt       = 0.1;%100 ms window
     alpha     = 0.9;
      tau_f    = 1;
      Q        =  (1/tau_f)*[-1.1 1.1;
                             1.6 -1.6];
 %%%%%%%%%%%%%%%%%%%%%%%%%CHANGED DUTY CYCLE %%%%%%%%%%%%%%%%%%%%%%% 
 
     case 101     %FAST
      dt       = 0.1;%100 ms window
     alpha     = 0.9;
      tau_f    = 1/15;
      Q        =  (1/tau_f)*[-1.1 1.1;
                             1.6 -1.6]; 
     case 102    %SLOWER
      dt       = 0.1;%100 ms window
     alpha     = 0.5;
      tau_f    = 1/15;
      Q        =  (1/tau_f)*[-1.1 1.1;
                             1.6 -1.6];                 
     case 103    %FASTER
      dt       = 0.1;%100 ms window
     alpha     = 0.1;
      tau_f    = 1/15;
      Q        =  (1/tau_f)*[-1.1 1.1;
                             1.6 -1.6];   
 %%%%%%%%%%%%%%%%%%%%%%%%%CHANGED noise level %%%%%%%%%%%%%%%%%%%%%%% 
                         
     case 501    %FASTER
      dt       = 0.1;%100 ms window
     alpha     = 0.9;
      tau_f    = 1/15;
      prec     = 5;
      Q        =  (1/tau_f)*[-1.1 1.1;
                             1.6 -1.6];  
     case 502    %FASTER
      dt       = 0.1;%100 ms window
     alpha     = 0.9;
      tau_f    = 10/3;
      Q        =  (1/tau_f)*[-1.1 1.1;
                             1.6 -1.6];  
                         
 end
 
%% Observation Window Determination


prec           = 10; %(1/nm^2);
obs_wind_left  = (0.1 :dt :20-(0.1))'; %same size as obs(COLUMN)
            
%obs all

%% set up-parameters 
  %decide  here observatoion windows 
 %observation windows first then T_i(<<<<T_L1 of the obseravtion) is small then  and 
 %T_f>>>> Last side of the observation Window 

%  Q            =  (1/tau_f)*[-.1 .1 0;...
%                              .1 -20.1 20;...
%                              0 10 -10];    
%  
%  Q            =  (1/tau_f)*[-10 10 0;...
%                              10 -210 200;...
%                              0 100 -100];         
% Q            =  (1/tau_f)*[-1 1;
%                             1.5 -1.5]; 
s_init        =  1; 

T_i           =  obs_wind_left(1)      - (0.05); %
                      
T_f           =  obs_wind_left(end)   +  0.2;  % 


% 0.1 is critical this is critical, when you choose small again
% again nan appears after interp1

mean_state    =  [1;7]; % mean state(1 2 3) = (1 2 5)(units of space)


%% simulate data and such

M             =  zeros(2,2);

for i=1:2
    for j=1:2
        if ~isequal(i,j)
        M(i,j) = Q(i,j)/(-Q(i,i));
        else
        M(i,i) = 0;
        end
    end
end

     time          = T_i;

     stID          = s_init;
     
     trace_t       = time;
     
     trace_s       = stID;


while (time < T_f)
          
    t_d         = log(rand) / (Q(stID,stID));
    
    stID        = sample_categorical(M(stID,:));%it samples based onthe rows of the transition matrix
    
    time        = time + t_d;

    trace_t     = [trace_t; time]; 
    
    trace_s     = [trace_s; stID];
    
end
 
trace_t_full    = trace_t;

trace_s_full    = trace_s;


% last_ind        = find(trace_t>T_f,1);

trace_t         = trace_t(1:end-1);
trace_s         = trace_s(1:end-1);



%% ground-truth

 ground.Q           = Q;
 ground.traj_t      = trace_t;
 ground.traj_s      = trace_s;
 ground.T_i         = T_i;
 ground.T_f         = T_f;
 ground.mean_state  = mean_state;
 
%% observation extraction
% spit out the observations and the observation windows

%%% All observations

[tx,sx]    =  stairs(trace_t_full,trace_s_full);

%% Fixing the holding states: (Jump Times, Holding States)

sleft     =  nan(length(trace_s_full(:,1)),1);
tleft     =  nan(length(trace_t_full(:,1)),1);%column

for n     =  1:length(trace_s_full(:,1))
    
sleft(n)  =  sx(2*n-1); % Holding State IDS
tleft(n)  =  tx(2*n-1); % Jump times to the holding states
    
end


sright    = nan(length(trace_t_full(:,1))-1,1);%column
tright    = nan(length(trace_t_full(:,1))-1,1);%column

for n=1:length(trace_t_full(:,1))-1
    
sright(n) = sx(2*n);
tright(n) = tx(2*n);
    
end

 
%% Holding States-----PART1
% obs_wind_left  =  0.1*obs_wind_left;
obs_wind_right = obs_wind_left + alpha*dt; %0 .01 is the exposure (COLUMN)



obsSt               = nan(1,length(obs_wind_right)); % Holding State Preallocation(ROW)

options.T_f         = T_f;
options.T_i         = T_i;


%% Finding the indexes contributing to an observation
 
        

        all_times                = sort([obs_wind_left;obs_wind_right;trace_t],'ascend');
        
        all_states               = add_pts(trace_t,trace_s,all_times,options);
                   
        all_t_d                  = [diff(all_times);nan];
        
        ff                       = nan(length(obs_wind_left),1);
        
        idx                      = cell(1,length(obs_wind_left));
        
        for n   = 1:length(obs_wind_left)
            
        idx{n}  = find((all_times>=obs_wind_left(n))&all_times<obs_wind_right(n));
        
        if ((abs(sum(all_t_d(idx{n}))-(obs_wind_right(1)-obs_wind_left(1))))>100*eps) %recall 0.01 is
                                                                 %the window size
            keyboard
        end
        
        ff(n)   = sum(all_t_d(idx{n})) ;
        
        end 
                
%-------------------------------------------------------------------------- 


%% Average Calculation  during integration time

for j =1:length(obs_wind_right)
    
    obsSt(j) = (1/(obs_wind_right(1)-obs_wind_left(1)))*(sum(all_t_d(idx{j}).*mean_state(all_states(idx{j})))) + (1/sqrt(prec))*randn(1);
   
end

observation.obs     = obsSt;
observation.t_left  = obs_wind_left';
observation.t_right = obs_wind_right';
observation.prec    = prec;



if isequal(length(tleft),2)

        disp('no transtion occured!');
else
    %%
    if show_demo

    
    % ---------------------------------------------------------------------
    fig = figure(1);
    fig.Name = 'Gillespie Trajectory';
    clf
  axes1 =   subplot(2,1,1);
  axes2 =   subplot(2,1,2);

%% Gillespie Trajectory
axes(axes1)

p1(1)      =  plot(tx(1:end-1),sx(1:end-1),'-mo',...
  'LineWidth',1);

hold on

p1(2)      =  plot(tleft(1:end-1)',sleft(1:end-1)','o',...
    'MarkerEdgeColor','k',...
    'MarkerFaceColor',[.3 .3 .3],...
    'MarkerSize',5);

p1(3)      =  plot(tright(1:end-1)',sright(1:end-1)','o',...
    'MarkerEdgeColor','k',...
    'MarkerFaceColor',[.9 1 .9],...
    'MarkerSize',5);

p1(3)      =  plot(tright(end)',sright(end)','o',...
    'MarkerEdgeColor','k',...
    'MarkerFaceColor',[.3 .3 .3],...
    'MarkerSize',5);

p1(1).LineWidth = 1 ;
line(tright(1:end-1)'.*[1;1],[0,4],'linestyle',':','color','k');
line(T_i.*[1 1],[0,4],'linestyle','--','color','k','linewidth',2);
line(T_f.*[1 1],[0,4],'linestyle','--','color','k','linewidth',2);


xlabel('Time (s)')
ylabel('States')
ylim([0,4])

xlim_0   =  T_i - 0.05*(T_f-T_i);
xlim_end =  T_f + 0.05*(T_f-T_i) ;

xlim([xlim_0 xlim_end])
yticks([1 2 3 4 ])
yticklabels({'\sigma_{1}','\sigma_{2}','\sigma_{3}','',''})

title('Gillespie Trajectory')


hold off


%% Points from the trajectory
axes(axes2)

pp(1)      =  plot(trace_t',trace_s','o',...
    'MarkerEdgeColor','k',...
    'MarkerFaceColor',[.3 .3 .3],...
    'MarkerSize',5);

line(T_i.*[1 1],[0,6],'linestyle','--','color','k','linewidth',2);
line(T_f.*[1 1],[0,6],'linestyle','--','color','k','linewidth',2);
line(trace_t(1:end-1).*[1 1],[0,6],'linestyle',':','color','k');


pp(1).LineWidth = 1 ;

xlabel('Time (s)')
ylabel('States')
ylim([0,4])

xlim_0   =  T_i - 0.07*(T_f-T_i);
xlim_end =  T_f + 0.07*(T_f-T_i) ;

xlim([xlim_0 xlim_end])
yticks([1 2 3 4 ])
yticklabels({'\sigma_{1}','\sigma_{2}','\sigma_{3}','',''})

title('Holding States and Jump Times from Gillespie')

hold off

%% Observations 
    fig = figure(2);
    fig.Name = 'Observations from the Gillespie trajectory';
    clf
  axes1 =   subplot(2,1,1);
  axes2 =   subplot(2,1,2);
  
%%% ONLY Gillespie
%%% Trajectory-----------------------------------------------------------------
  
axes(axes1)

ppp(1)      =  plot(tx(1:end-1),sx(1:end-1),'-mo');

ppp(1).LineWidth = 1 ;

hold on

ppp(2)      =  plot(tleft(1:end-1)',sleft(1:end-1)','o',...
    'MarkerEdgeColor','k',...
    'MarkerFaceColor',[.3 .3 .3],...
    'MarkerSize',5);

ppp(3)      =  plot(tright(1:end-1)',sright(1:end-1)','o',...
    'MarkerEdgeColor','k',...
    'MarkerFaceColor',[.9 1 .9],...
    'MarkerSize',5);

ppp(4)      =  plot(tright(end)',sright(end)','o',...
    'MarkerEdgeColor','k',...
    'MarkerFaceColor',[.3 .3 .3],...
    'MarkerSize',5);

line(tright(1:end-1)'.*[1;1],[0,4],'linestyle',':','color','k');
line(T_i.*[1 1],[0,4],'linestyle','--','color','k','linewidth',2);
line(T_f.*[1 1],[0,4],'linestyle','--','color','k','linewidth',2);


xlabel('Time (s)')
ylabel('States')
ylim([0,4])

xlim_0   =  T_i - 0.07*(T_f-T_i);
xlim_end =  T_f + 0.07*(T_f-T_i) ;

xlim([xlim_0 xlim_end])
yticks([1 2 3 4 ])
yticklabels({'\sigma_{1}','\sigma_{2}','','',''})

ylabel({'States'})

title('Gillespie Trajecory')



%------------------------------------------------------------------------------
%%% ONLY Observations 

axes(axes2)
  


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for j=1:length(obs_wind_right)
    
l =  line([obs_wind_left(j) obs_wind_right(j)],[obsSt(j) obsSt(j)],'color','k','LineWidth',5);
hold on

end


hold on


xlim_0   =  T_i - 0.07*(T_f-T_i);
xlim_end =  T_f + 0.07*(T_f-T_i) ;


xlim([xlim_0 xlim_end])




l1 = line((obs_wind_left)'.*[1 ;1],[0,6],'linestyle',':','color','g','LineWidth',1);

l2 = line(obs_wind_right'.*[1; 1],[0,6],'linestyle',':','color','b','LineWidth',1);

l3 = line([T_i,T_f],[1;5]'.*[1;1],'linestyle','-','color','c','LineWidth',1);

line(T_i.*[1 1],[0,6],'linestyle','--','color','k','linewidth',2);

line(T_f.*[1 1],[0,6],'linestyle','--','color','k','linewidth',2);

legend([l(1) l1(1) l2(1) l3(1)],'observations','{observation window left end point}','{observation window right end point}','mean states')

hold off

xlabel('Time (s)')
ylabel({'Space (nm)'})
ylim([0,6])


xlim([xlim_0 xlim_end])
yticks([1 2 3 4 5 6])

text(-0.03,1,'\mu_{\sigma_1}','color','cyan')
text(-0.03,5,'\mu_{\sigma_2}','color','cyan')



title('Simulated Observations')
box on

save(['simulated_tag_' num2str(tag),'_',num2str(alpha*dt),'.mat'],'ground','observation','units','-v7.3')
    end
end

%% Holding States-----PART2
% obs_wind_left  =  0.1*obs_wind_left;
alpha = 0.5;
obs_wind_right = obs_wind_left + alpha*dt; %0 .01 is the exposure (COLUMN)



obsSt               = nan(1,length(obs_wind_right)); % Holding State Preallocation(ROW)

options.T_f         = T_f;
options.T_i         = T_i;


%% Finding the indexes contributing to an observation
 
        

        all_times                = sort([obs_wind_left;obs_wind_right;trace_t],'ascend');
        
        all_states               = add_pts(trace_t,trace_s,all_times,options);
                   
        all_t_d                  = [diff(all_times);nan];
        
        ff                       = nan(length(obs_wind_left),1);
        
        idx                      = cell(1,length(obs_wind_left));
        
        for n   = 1:length(obs_wind_left)
            
        idx{n}  = find((all_times>=obs_wind_left(n))&all_times<obs_wind_right(n));
        
        if ((abs(sum(all_t_d(idx{n}))-(obs_wind_right(1)-obs_wind_left(1))))>100*eps) %recall 0.01 is
                                                                 %the window size
            keyboard
        end
        
        ff(n)   = sum(all_t_d(idx{n})) ;
        
        end 
                
%-------------------------------------------------------------------------- 


%% Average Calculation  during integration time

for j =1:length(obs_wind_right)
    
    obsSt(j) = (1/(obs_wind_right(1)-obs_wind_left(1)))*(sum(all_t_d(idx{j}).*mean_state(all_states(idx{j})))) + (1/sqrt(prec))*randn(1);
   
end

observation.obs     = obsSt;
observation.t_left  = obs_wind_left';
observation.t_right = obs_wind_right';
observation.prec    = prec;



if isequal(length(tleft),2)

        disp('no transtion occured!');
else
    %%
    if show_demo

    
    % ---------------------------------------------------------------------
    fig = figure(1);
    fig.Name = 'Gillespie Trajectory';
    clf
  axes1 =   subplot(2,1,1);
  axes2 =   subplot(2,1,2);

%% Gillespie Trajectory
axes(axes1)

p1(1)      =  plot(tx(1:end-1),sx(1:end-1),'-mo',...
  'LineWidth',1);

hold on

p1(2)      =  plot(tleft(1:end-1)',sleft(1:end-1)','o',...
    'MarkerEdgeColor','k',...
    'MarkerFaceColor',[.3 .3 .3],...
    'MarkerSize',5);

p1(3)      =  plot(tright(1:end-1)',sright(1:end-1)','o',...
    'MarkerEdgeColor','k',...
    'MarkerFaceColor',[.9 1 .9],...
    'MarkerSize',5);

p1(3)      =  plot(tright(end)',sright(end)','o',...
    'MarkerEdgeColor','k',...
    'MarkerFaceColor',[.3 .3 .3],...
    'MarkerSize',5);

p1(1).LineWidth = 1 ;
line(tright(1:end-1)'.*[1;1],[0,4],'linestyle',':','color','k');
line(T_i.*[1 1],[0,4],'linestyle','--','color','k','linewidth',2);
line(T_f.*[1 1],[0,4],'linestyle','--','color','k','linewidth',2);


xlabel('Time (s)')
ylabel('States')
ylim([0,4])

xlim_0   =  T_i - 0.05*(T_f-T_i);
xlim_end =  T_f + 0.05*(T_f-T_i) ;

xlim([xlim_0 xlim_end])
yticks([1 2 3 4 ])
yticklabels({'\sigma_{1}','\sigma_{2}','\sigma_{3}','',''})

title('Gillespie Trajectory')


hold off


%% Points from the trajectory
axes(axes2)

pp(1)      =  plot(trace_t',trace_s','o',...
    'MarkerEdgeColor','k',...
    'MarkerFaceColor',[.3 .3 .3],...
    'MarkerSize',5);

line(T_i.*[1 1],[0,6],'linestyle','--','color','k','linewidth',2);
line(T_f.*[1 1],[0,6],'linestyle','--','color','k','linewidth',2);
line(trace_t(1:end-1).*[1 1],[0,6],'linestyle',':','color','k');


pp(1).LineWidth = 1 ;

xlabel('Time (s)')
ylabel('States')
ylim([0,4])

xlim_0   =  T_i - 0.07*(T_f-T_i);
xlim_end =  T_f + 0.07*(T_f-T_i) ;

xlim([xlim_0 xlim_end])
yticks([1 2 3 4 ])
yticklabels({'\sigma_{1}','\sigma_{2}','\sigma_{3}','',''})

title('Holding States and Jump Times from Gillespie')

hold off

%% Observations 
    fig = figure(2);
    fig.Name = 'Observations from the Gillespie trajectory';
    clf
  axes1 =   subplot(2,1,1);
  axes2 =   subplot(2,1,2);
  
%%% ONLY Gillespie
%%% Trajectory-----------------------------------------------------------------
  
axes(axes1)

ppp(1)      =  plot(tx(1:end-1),sx(1:end-1),'-mo');

ppp(1).LineWidth = 1 ;

hold on

ppp(2)      =  plot(tleft(1:end-1)',sleft(1:end-1)','o',...
    'MarkerEdgeColor','k',...
    'MarkerFaceColor',[.3 .3 .3],...
    'MarkerSize',5);

ppp(3)      =  plot(tright(1:end-1)',sright(1:end-1)','o',...
    'MarkerEdgeColor','k',...
    'MarkerFaceColor',[.9 1 .9],...
    'MarkerSize',5);

ppp(4)      =  plot(tright(end)',sright(end)','o',...
    'MarkerEdgeColor','k',...
    'MarkerFaceColor',[.3 .3 .3],...
    'MarkerSize',5);

line(tright(1:end-1)'.*[1;1],[0,4],'linestyle',':','color','k');
line(T_i.*[1 1],[0,4],'linestyle','--','color','k','linewidth',2);
line(T_f.*[1 1],[0,4],'linestyle','--','color','k','linewidth',2);


xlabel('Time (s)')
ylabel('States')
ylim([0,4])

xlim_0   =  T_i - 0.07*(T_f-T_i);
xlim_end =  T_f + 0.07*(T_f-T_i) ;

xlim([xlim_0 xlim_end])
yticks([1 2 3 4 ])
yticklabels({'\sigma_{1}','\sigma_{2}','','',''})

ylabel({'States'})

title('Gillespie Trajecory')



%------------------------------------------------------------------------------
%%% ONLY Observations 

axes(axes2)
  


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for j=1:length(obs_wind_right)
    
l =  line([obs_wind_left(j) obs_wind_right(j)],[obsSt(j) obsSt(j)],'color','k','LineWidth',5);
hold on

end


hold on


xlim_0   =  T_i - 0.07*(T_f-T_i);
xlim_end =  T_f + 0.07*(T_f-T_i) ;


xlim([xlim_0 xlim_end])




l1 = line((obs_wind_left)'.*[1 ;1],[0,6],'linestyle',':','color','g','LineWidth',1);

l2 = line(obs_wind_right'.*[1; 1],[0,6],'linestyle',':','color','b','LineWidth',1);

l3 = line([T_i,T_f],[1;5]'.*[1;1],'linestyle','-','color','c','LineWidth',1);

line(T_i.*[1 1],[0,6],'linestyle','--','color','k','linewidth',2);

line(T_f.*[1 1],[0,6],'linestyle','--','color','k','linewidth',2);

legend([l(1) l1(1) l2(1) l3(1)],'observations','{observation window left end point}','{observation window right end point}','mean states')

hold off

xlabel('Time (s)')
ylabel({'Space (nm)'})
ylim([0,6])


xlim([xlim_0 xlim_end])
yticks([1 2 3 4 5 6])

text(-0.03,1,'\mu_{\sigma_1}','color','cyan')
text(-0.03,5,'\mu_{\sigma_2}','color','cyan')



title('Simulated Observations')
box on

save(['simulated_tag_' num2str(tag),'_',num2str(alpha*dt),'.mat'],'ground','observation','units','-v7.3')
    end
end

%% Holding States-----PART3
% obs_wind_left  =  0.1*obs_wind_left;
alpha = 0.1;
obs_wind_right = obs_wind_left + alpha*dt; %0 .01 is the exposure (COLUMN)



obsSt               = nan(1,length(obs_wind_right)); % Holding State Preallocation(ROW)

options.T_f         = T_f;
options.T_i         = T_i;


%% Finding the indexes contributing to an observation
 
        

        all_times                = sort([obs_wind_left;obs_wind_right;trace_t],'ascend');
        
        all_states               = add_pts(trace_t,trace_s,all_times,options);
                   
        all_t_d                  = [diff(all_times);nan];
        
        ff                       = nan(length(obs_wind_left),1);
        
        idx                      = cell(1,length(obs_wind_left));
        
        for n   = 1:length(obs_wind_left)
            
        idx{n}  = find((all_times>=obs_wind_left(n))&all_times<obs_wind_right(n));
        
        if ((abs(sum(all_t_d(idx{n}))-(obs_wind_right(1)-obs_wind_left(1))))>100*eps) %recall 0.01 is
                                                                 %the window size
            keyboard
        end
        
        ff(n)   = sum(all_t_d(idx{n})) ;
        
        end 
                
%-------------------------------------------------------------------------- 


%% Average Calculation  during integration time

for j =1:length(obs_wind_right)
    
    obsSt(j) = (1/(obs_wind_right(1)-obs_wind_left(1)))*(sum(all_t_d(idx{j}).*mean_state(all_states(idx{j})))) + (1/sqrt(prec))*randn(1);
   
end

observation.obs     = obsSt;
observation.t_left  = obs_wind_left';
observation.t_right = obs_wind_right';
observation.prec    = prec;



if isequal(length(tleft),2)

        disp('no transtion occured!');
else
    %%
    if show_demo

    
    % ---------------------------------------------------------------------
    fig = figure(1);
    fig.Name = 'Gillespie Trajectory';
    clf
  axes1 =   subplot(2,1,1);
  axes2 =   subplot(2,1,2);

%% Gillespie Trajectory
axes(axes1)

p1(1)      =  plot(tx(1:end-1),sx(1:end-1),'-mo',...
  'LineWidth',1);

hold on

p1(2)      =  plot(tleft(1:end-1)',sleft(1:end-1)','o',...
    'MarkerEdgeColor','k',...
    'MarkerFaceColor',[.3 .3 .3],...
    'MarkerSize',5);

p1(3)      =  plot(tright(1:end-1)',sright(1:end-1)','o',...
    'MarkerEdgeColor','k',...
    'MarkerFaceColor',[.9 1 .9],...
    'MarkerSize',5);

p1(3)      =  plot(tright(end)',sright(end)','o',...
    'MarkerEdgeColor','k',...
    'MarkerFaceColor',[.3 .3 .3],...
    'MarkerSize',5);

p1(1).LineWidth = 1 ;
line(tright(1:end-1)'.*[1;1],[0,4],'linestyle',':','color','k');
line(T_i.*[1 1],[0,4],'linestyle','--','color','k','linewidth',2);
line(T_f.*[1 1],[0,4],'linestyle','--','color','k','linewidth',2);


xlabel('Time (s)')
ylabel('States')
ylim([0,4])

xlim_0   =  T_i - 0.05*(T_f-T_i);
xlim_end =  T_f + 0.05*(T_f-T_i) ;

xlim([xlim_0 xlim_end])
yticks([1 2 3 4 ])
yticklabels({'\sigma_{1}','\sigma_{2}','\sigma_{3}','',''})

title('Gillespie Trajectory')


hold off


%% Points from the trajectory
axes(axes2)

pp(1)      =  plot(trace_t',trace_s','o',...
    'MarkerEdgeColor','k',...
    'MarkerFaceColor',[.3 .3 .3],...
    'MarkerSize',5);

line(T_i.*[1 1],[0,6],'linestyle','--','color','k','linewidth',2);
line(T_f.*[1 1],[0,6],'linestyle','--','color','k','linewidth',2);
line(trace_t(1:end-1).*[1 1],[0,6],'linestyle',':','color','k');


pp(1).LineWidth = 1 ;

xlabel('Time (s)')
ylabel('States')
ylim([0,4])

xlim_0   =  T_i - 0.07*(T_f-T_i);
xlim_end =  T_f + 0.07*(T_f-T_i) ;

xlim([xlim_0 xlim_end])
yticks([1 2 3 4 ])
yticklabels({'\sigma_{1}','\sigma_{2}','\sigma_{3}','',''})

title('Holding States and Jump Times from Gillespie')

hold off

%% Observations 
    fig = figure(2);
    fig.Name = 'Observations from the Gillespie trajectory';
    clf
  axes1 =   subplot(2,1,1);
  axes2 =   subplot(2,1,2);
  
%%% ONLY Gillespie
%%% Trajectory-----------------------------------------------------------------
  
axes(axes1)

ppp(1)      =  plot(tx(1:end-1),sx(1:end-1),'-mo');

ppp(1).LineWidth = 1 ;

hold on

ppp(2)      =  plot(tleft(1:end-1)',sleft(1:end-1)','o',...
    'MarkerEdgeColor','k',...
    'MarkerFaceColor',[.3 .3 .3],...
    'MarkerSize',5);

ppp(3)      =  plot(tright(1:end-1)',sright(1:end-1)','o',...
    'MarkerEdgeColor','k',...
    'MarkerFaceColor',[.9 1 .9],...
    'MarkerSize',5);

ppp(4)      =  plot(tright(end)',sright(end)','o',...
    'MarkerEdgeColor','k',...
    'MarkerFaceColor',[.3 .3 .3],...
    'MarkerSize',5);

line(tright(1:end-1)'.*[1;1],[0,4],'linestyle',':','color','k');
line(T_i.*[1 1],[0,4],'linestyle','--','color','k','linewidth',2);
line(T_f.*[1 1],[0,4],'linestyle','--','color','k','linewidth',2);


xlabel('Time (s)')
ylabel('States')
ylim([0,4])

xlim_0   =  T_i - 0.07*(T_f-T_i);
xlim_end =  T_f + 0.07*(T_f-T_i) ;

xlim([xlim_0 xlim_end])
yticks([1 2 3 4 ])
yticklabels({'\sigma_{1}','\sigma_{2}','','',''})

ylabel({'States'})

title('Gillespie Trajecory')



%------------------------------------------------------------------------------
%%% ONLY Observations 

axes(axes2)
  


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for j=1:length(obs_wind_right)
    
l =  line([obs_wind_left(j) obs_wind_right(j)],[obsSt(j) obsSt(j)],'color','k','LineWidth',5);
hold on

end


hold on


xlim_0   =  T_i - 0.07*(T_f-T_i);
xlim_end =  T_f + 0.07*(T_f-T_i) ;


xlim([xlim_0 xlim_end])




l1 = line((obs_wind_left)'.*[1 ;1],[0,6],'linestyle',':','color','g','LineWidth',1);

l2 = line(obs_wind_right'.*[1; 1],[0,6],'linestyle',':','color','b','LineWidth',1);

l3 = line([T_i,T_f],[1;5]'.*[1;1],'linestyle','-','color','c','LineWidth',1);

line(T_i.*[1 1],[0,6],'linestyle','--','color','k','linewidth',2);

line(T_f.*[1 1],[0,6],'linestyle','--','color','k','linewidth',2);

legend([l(1) l1(1) l2(1) l3(1)],'observations','{observation window left end point}','{observation window right end point}','mean states')

hold off

xlabel('Time (s)')
ylabel({'Space (nm)'})
ylim([0,6])


xlim([xlim_0 xlim_end])
yticks([1 2 3 4 5 6])

text(-0.03,1,'\mu_{\sigma_1}','color','cyan')
text(-0.03,5,'\mu_{\sigma_2}','color','cyan')



title('Simulated Observations')
box on

save(['simulated_tag_' num2str(tag),'_',num2str(alpha*dt),'.mat'],'ground','observation','units','-v7.3')
    end
end



        