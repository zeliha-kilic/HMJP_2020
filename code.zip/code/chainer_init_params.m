function params = chainer_init_params(opts)

%% Units
params.units    =   opts.units   ;

%% Observation Parameters


params.obs      =   opts.obs     ;

params.t_left   =   opts.t_left  ;

params.t_right  =   opts.t_right ;

params.prec     =   opts.prec    ;

params.T_i      =   opts.T_i     ;

params.T_f      =   opts.T_f     ;


%% Hyperparameters
       
params.M        =   opts.M       ;
 
params.alpha    =   opts.alpha   ;
 
params.beta     =   opts.beta    ;

params.eta      =   opts.eta     ;   

params.kappa    =   opts.kappa   ;

params.phi      =   opts.phi     ;

%% -----Debugging RATES and PROBS

params.ground.t_t      = opts.ground.t_t;

params.ground.t_s      = opts.ground.t_s;

params.ground.Q        = opts.ground.Q;

params.ground.escrate  = opts.ground.escrate;

params.ground.mean_st  = opts.ground.mean_state;

%% aux sampler's params

%  MCMC stride

params.i_skip   =   1            ;

