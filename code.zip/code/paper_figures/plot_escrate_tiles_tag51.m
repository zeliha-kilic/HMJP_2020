%% Load the Data
%  load('')
close all

addpath('fig')

figure1 = figure('Units','inch','Position',[0 0 5.5 5])

% set(gcf,'WindowStyle','docked');
set(gcf,'color','w')

movegui(gcf,'center')

% set(gcf,'windowstyle','docked')


        load('/Users/zelihakilic/Dropbox (ASU)/zeliha_presselab/Project2_MJP/manuscript_figures_2states/HMM_MJP_both_work/MJP_tag_51_new.mat');
        raw_data = load('/Users/zelihakilic/Dropbox (ASU)/zeliha_presselab/Project2_MJP/manuscript_figures_2states/HMM_MJP_both_work/sim_tag_51.mat');
        


m_length     = size(chain.Q);
chain.length = m_length(3);


chain.i = (1:1:chain.length);


burnin   = 1000;

quant_enu = 19;

quant_val = linspace(0,1,2*quant_enu +3);  

d_sample  = 1;

idx       = (burnin:d_sample:m_length (3));

bin_c     = 20;

%% -----------------------------MJP DATA_SECTION 1----------------------------------

P_mjp     = squeeze(nan(chain.params.M,chain.params.M,length(idx)));

for j=1:length(idx)   
    
P_mjp(:,:,j) = abs( squeeze(chain.Q(:,:,idx(j))) ) ;

end


P11_quant    = quantile(P_mjp(1,1,:),quant_val);

P12_quant    = quantile(P_mjp(1,2,:),quant_val);

P21_quant    = quantile(P_mjp(2,1,:),quant_val);

P22_quant    = quantile(P_mjp(2,2,:),quant_val);



%% -----------------------------PLOT MATRIX----------------------------------

ytemp = linspace(10^-1,1000,500);

color_sty  = winter(8);

[S,AX,BigAx,H,HAx]= plotmatrix([-squeeze(chain.Q(1,1,idx)) -squeeze(chain.Q(2,2,idx))] );

H(1).BinWidth = .45;
H(1).FaceColor = color_sty(3,:);
H(2).FaceColor = color_sty(3,:);
for j=1:2
    for i=1:2
    S(i,j).Color = color_sty(3,:);
    end
end
H(2).BinWidth = 0.75;
H(1).Normalization = 'pdf';
H(2).Normalization ='pdf';

delete(subplot(length(AX),length(AX),2));

AX(1,1).YTick = [];
hold(HAx(1,1),'on');
for l =2
      f_hmm_1  =  patch( [P11_quant(l) P11_quant(l) P11_quant(end-l+1) P11_quant(end-l+1)],[0 max([ max(H(1,1).Values)])+0.1 max([max(H(1,1).Values) ])+0.1 0],...
    get(H(1,1),'FaceColor'),'FaceAlpha',0.2,'Parent',HAx(1,1));
    
    set(f_hmm_1,'edgecolor','none')  %h(4)
end
hold on
l1 = line(ytemp,gampdf(ytemp,chain.params.eta/2,2/(chain.params.eta*chain.params.beta)),'linestyle','-','color','m','linewidth',2,'Parent',HAx(1,1));
l2 = xline(HAx(1,1),chain.params.ground.escrate(1),':','color','g','LineWidth',2);

hold(HAx(1,2),'on');
for l =2
      f_hmm_2  =  patch(  [P22_quant(l) P22_quant(l) P22_quant(end-l+1) P22_quant(end-l+1)],  [0 max([ max(H(1,2).Values)])+0.01 max([max(H(1,2).Values) ])+0.01 0],...
    get(H(1,1),'FaceColor'),'FaceAlpha',0.2,'Parent',HAx(1,2));
    
    set(f_hmm_2,'edgecolor','none')  %h(4)
end
hold on
line(ytemp,gampdf(ytemp,chain.params.eta/2,2/(chain.params.eta*chain.params.beta)),'linestyle','-','color','m','linewidth',2,'Parent',HAx(1,2));
l2 = xline(HAx(1,2),chain.params.ground.escrate(2),':','color','g','LineWidth',2);


hold(AX(2,1),'on')
xline(AX(2,1),chain.params.ground.escrate(1),':','color','g','LineWidth',2);
yline(AX(2,1),chain.params.ground.escrate(2),':','color','g','LineWidth',2);

hold(AX(2,2),'on')
yline(AX(2,2),chain.params.ground.escrate(2),':','color','g','LineWidth',2);

leg = legend('HMJP post. prob. distr.','95% conf. int.','Prior distr.','True rate');
leg.Location    = 'southoutside';

leg.Orientation = 'horizontal';

leg.Position    = [0.014027731710686,0.944435731344741,0.993686868686871,0.041666666666667];

leg.NumColumns  = 4;

legend boxoff;
HAx(1,1).YLim = [0 0.200];
HAx(1,2).YLim = [0 0.135];
xlim_h1 = HAx(1,1).XLim;
HAx(1,1).XLim = [0 xlim_h1(2)];
xlim_h2 = HAx(1,2).XLim;
HAx(1,2).XLim = [0 xlim_h2(2)];
xlim_h3 = AX(2,1).XLim;
AX(2,1).XLim = [0 xlim_h3(2)];

AX(1,1).YLabel.String='Post. prob. distr.'; 
AX(2,1).YLabel.String='\lambda_{\sigma_{2}} (s^{-1})'; 
AX(2,1).XLabel.String='\lambda_{\sigma_{1}} (s^{-1})'; 
AX(2,2).XLabel.String='\lambda_{\sigma_{2}} (s^{-1})'; 
% end
% end

cd PDFs
addpath('fig1')

savefig esc_rate_corner_tag_51
export_fig esc_rate_corner_tag_51 -pdf
cd ..














