function plot_all_emissions_dif_dutycycles_seq(tag1)

addpath('fig')

figure('Units','inch','Position',[0 0 7.3 4])

 
set(gcf,'color','w')
clf
movegui(gcf,'center')



if isempty(tag1)
    
tag1 = 100;
else
switch tag1
    

        case 100

        data_mjp   = load('/Users/zelihakilic/Dropbox (ASU)/zeliha_presselab/Project2_MJP/manuscript_figures_2states/HMM_MJP_both_work/MJP_tag_51_new.mat');
        data_mjp_2 = load('/Users/zelihakilic/Dropbox (ASU)/zeliha_presselab/Project2_MJP/project2_revision/data/MJP_tag_501.mat');
        data_mjp_3 = load('/Users/zelihakilic/Dropbox (ASU)/zeliha_presselab/Project2_MJP/project2_revision/data/MJP_tag_502.mat');


        raw_data   = load('/Users/zelihakilic/Dropbox (ASU)/zeliha_presselab/Project2_MJP/manuscript_figures_2states/HMM_MJP_both_work/sim_tag_51.mat');
        raw_data_2 = load('/Users/zelihakilic/Dropbox (ASU)/zeliha_presselab/Project2_MJP/project2_revision/simulated_tag_501_prec_5.mat');
        raw_data_3 = load('/Users/zelihakilic/Dropbox (ASU)/zeliha_presselab/Project2_MJP/project2_revision/simulated_tag_501_prec_3.3333.mat');
        
%         gen_lim  = linspace(0,1,200); 
        ep_s = 0.02;
        
end

%% Visualizing escape rates and Mean Dwell Times
data_mjp = data_mjp.chain ;

s_1        = size(data_mjp.P);
s_2        = size(data_mjp_2.P);
s_3        = size(data_mjp_3.P);

burnin   = 2000;

quant_enu = 19;

quant_val = linspace(0,1,2*quant_enu +3);  

d_sample  = 1;

idx       = (burnin:d_sample:s_1(3));
idx_2       = (burnin:d_sample:s_2(3));
idx_3       = (burnin:d_sample:s_3(3));

bin_c     = 20;

%% -----------------------------MJP DATA_SECTION 1----------------------------------

P_mjp     = squeeze(nan(data_mjp.params.M,length(idx)));

for j=1:length(idx)   
    
P_mjp(:,j) = abs( squeeze(data_mjp.mean_st(:,idx(j))) ) ;

end


P11_quant    = quantile(P_mjp(1,:),quant_val);

P12_quant    = quantile(P_mjp(2,:),quant_val);

%% -----------------------------MJP DATA_SECTION 2----------------------------------


P_mjp_2     = squeeze(nan(data_mjp_2.params.M,length(idx_2)));

for j=1:length(idx_2)   
    
P_mjp_2(:,j) = abs( squeeze(data_mjp_2.mean_st(:,idx_2(j))) ) ;

end


P11_quant_2    = quantile(P_mjp_2(1,:),quant_val);

P12_quant_2    = quantile(P_mjp_2(2,:),quant_val);



%% -----------------------------MJP DATA_SECTION 3----------------------------------


P_mjp_3     = squeeze(nan(data_mjp_3.params.M,length(idx_3)));

for j=1:length(idx_3)   
    
P_mjp_3(:,j) = abs( squeeze(data_mjp_3.mean_st(:,idx_3(j))) ) ;

end


P11_quant_3    = quantile(P_mjp_3(1,:),quant_val);

P12_quant_3    = quantile(P_mjp_3(2,:),quant_val);


%% ---------------------------MJP DATA------------------------------------

burnin       = 5000;

quant_enu    = 19;

quant_val    = linspace(0,1,2*quant_enu +3);  

d_sample     = 1;

bin_c        =40;



%% True Transition Probability Matrix

true_P = data_mjp.params.ground.mean_st;
       
%%%%%%%%%%%%%%%%%%%%%%%%%%%




%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Emission rate for state 1-Data set (1)


p1 = subplot(2,3,1)
p1.OuterPosition = [0.046349809885932,0.526545506210598,0.299847135519519,0.397154267612938];
baseline1 = 0;

color_sty  = winter(8);
% axes11.OuterPosition = [0.070114073462584,0.655330882352941,0.401460383276518,0.24423810660665];
h1     = histogram(P_mjp(2,:),25,'normalization','pdf','Orientation','horizontal','Facealpha',0.5,'FaceColor',color_sty(3,:));%h(1)'FaceColor',[0.9100    0.4100    0.1700]
hold on
for l =2
      f_hmm_1  =  patch(      [0 max([max(h1.Values)])+0.5 max([max(h1.Values)])+0.5 0],[P12_quant(l) P12_quant(l) P12_quant(end-l+1) P12_quant(end-l+1)],...
get(h1(1),'FaceColor'),'FaceAlpha',0.2);
    
      set(f_hmm_1,'edgecolor','none')  %h(4)
end
p1.YLim = [6 8];

xLim        = p1.XLim;

l2          = line(get(gca,'XLim'),abs(true_P(2)).*[1 1],'linestyle',':','color','g','linewidth',2) %h(3)
ytemp = linspace(p1.YLim(1),p1.YLim(end),100);
stlevel_prior1 = plot(normpdf(ytemp,data_mjp.params.kappa,(0.1)),ytemp,'linestyle','-','color','m','linewidth',2)

t_1     = title('(a1)');
t_1.Position = [0.260660989662389,8.028645833333332,0];
ylabel('\mu_{\sigma_1}')

leg = legend('HMJP post. prob. distr.','95% conf. int.','True emis. rate','Prior distr.')   

leg.Location    = 'southoutside';

leg.Orientation = 'horizontal';

leg.Position    = [0.12070724758404,0.953116286900296,0.79467680608365,0.052083333333333];

leg.NumColumns = 4;

legend boxoff;

hold off

xticks(baseline1); xticklabels({'0.75'}); % Graph number on x axis at baseline (0)
box off
%% Emission rate for state 1-Data set (2)

p2 = subplot(2,3,2)
p2.OuterPosition = [0.319185264706513,0.526545506210598,0.250196484783932,0.397154267612938];

baseline2 = 0;

h2 = histogram(P_mjp_2(1,:),30,'normalization','pdf','Orientation','horizontal','Facealpha',0.5,'FaceColor',color_sty(3,:));

for l =2
      f_hmm_2  =  patch(    [0 max([ max(h2.Values)])+0.5 max([max(h2.Values) ])+0.5 0],[P11_quant_2(l) P11_quant_2(l) P11_quant_2(end-l+1) P11_quant_2(end-l+1)],...
    get(h2(1),'FaceColor'),'FaceAlpha',0.2);
    
    set(f_hmm_2,'edgecolor','none')  %h(4)
end

l2          = line(get(gca,'XLim'),abs(true_P(2)).*[1 1],'linestyle',':','color','g','linewidth',2) %h(3)
hold on
ytemp = linspace(p1.YLim(1),p1.YLim(end),100);
stlevel_prior1 = plot(normpdf(ytemp,data_mjp.params.kappa,(0.1)),ytemp,'linestyle','-','color','m','linewidth',2)

xticks(baseline2); xticklabels({'1.1'}); % Graph number on x axis at baseline
box off;
t_2     = title('(b1)');
t_2.Position = [0.260660989662389,8.028645833333332,0];
Y=gca; Y.YAxis.Visible='off';

p1p=p1.Position; p2p=p2.Position;
p2p(1)=p1p(1)+p1p(3)+.01; p2.Position=p2p; % Move subplot so they touch
p2.YLim = p1.YLim;
%% Emission rate for state 1-Data set (3)

p3 = subplot(2,3,3)
p3.OuterPosition = [0.542591061807962,0.526545543463501,0.271510143735757,0.40093657974882];

baseline3 = 0;

h3 = histogram(P_mjp_3(1,:),30,'normalization','pdf','Orientation','horizontal','Facealpha',0.5,'FaceColor',color_sty(3,:));
 
for l =2
      f_hmm_3  =  patch([0 max([max(h3.Values)])+0.5 max([max(h3.Values)])+0.5 0],[P11_quant_3(l) P11_quant_3(l) P11_quant_3(end-l+1) P11_quant_3(end-l+1)],...
          get(h3(1),'FaceColor'),'FaceAlpha',0.2);
    
      set(f_hmm_3,'edgecolor','none')  %h(4)
end

l2          = line(get(gca,'XLim'),abs(true_P(2)).*[1 1],'linestyle',':','color','g','linewidth',2) %h(3)
hold on
ytemp = linspace(p1.YLim(1),p1.YLim(end),100);
stlevel_prior1 = plot(normpdf(ytemp,data_mjp.params.kappa,(0.1)),ytemp,'linestyle','-','color','m','linewidth',2)

t_3     = title('(c1)');
t_3.Position = [0.187509196145192,8.027918781725887,0];
xticks(baseline3); xticklabels({'1.3'}); % Graph number on x axis at baseline
box off;
Y=gca; Y.YAxis.Visible='off';

p2p=p2.Position; p3p=p3.Position;
p3p(1)=p2p(1)+p2p(3)+.01; p3.Position=p3p; % Move subplot so they touch
p3.YLim = p1.YLim;
linkaxes([p1 p2 p3],'y')

%% Emission rate for state 1-Data set (4)

p4 = subplot(2,3,4)
% p4.OuterPosition = [0.59572627615681,0.526545570823267,0.208098054028074,0.408501251166625];
baseline4 = 0;

h4     = histogram(P_mjp(1,:),15,'normalization','pdf','Orientation','horizontal','Facealpha',0.5,'FaceColor',color_sty(3,:));
 
for l =2
      f_hmm_4  =  patch([0 max([max(h4.Values)])+0.5 max([max(h4.Values)])+0.5 0],[P11_quant(l) P11_quant(l) P11_quant(end-l+1) P11_quant(end-l+1)],...
          get(h4(1),'FaceColor'),'FaceAlpha',0.2);
    
      set(f_hmm_4,'edgecolor','none')  %h(4)
end

l2          = line(get(gca,'XLim'),abs(true_P(1)).*[1 1],'linestyle',':','color','g','linewidth',2) %h(3)
hold on
p4.YLim = [0.25 1.5];

ytemp = linspace(p4.YLim(1),p4.YLim(end),100);
stlevel_prior1 = plot(normpdf(ytemp,data_mjp.params.kappa,(0.1)),ytemp,'linestyle','-','color','m','linewidth',2)
t_4     = title('(a2)');
t_4.Position = [0.37500638621194,1.517903645833333,1.4e-14];
xticks(baseline3); xticklabels({'0.75'}); % Graph number on x axis at baseline
box off;
ylabel('\mu_{\sigma_2}')

xlabel('Post. prob. distr.','Position',[6.160717146737236,0.027918781725888])

%% Emission rate 2
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Emission rate for state 2-Data set (1)

p5 = subplot(2,3,5)

baseline5 = 0;

color_sty  = winter(8);
% axes11.OuterPosition = [0.070114073462584,0.655330882352941,0.401460383276518,0.24423810660665];
h5     = histogram(P_mjp_2(2,:),30,'normalization','pdf','Orientation','horizontal','Facealpha',0.5,'FaceColor',color_sty(3,:));%h(1)'FaceColor',[0.9100    0.4100    0.1700]
hold on
for l =2
      f_hmm_5  =  patch(      [0 max([max(h5.Values)])+0.5 max([max(h5.Values)])+0.5 0],[P12_quant_2(l) P12_quant_2(l) P12_quant_2(end-l+1) P12_quant_2(end-l+1)],...
get(h5(1),'FaceColor'),'FaceAlpha',0.2);
    
      set(f_hmm_5,'edgecolor','none')  %h(4)
end

xLim        = p5.XLim;

l2          = line(get(gca,'XLim'),abs(true_P(1)).*[1 1],'linestyle',':','color','g','linewidth',2) %h(3)
% ylim_0  = axes11.YLim;
% 
% h = get(gca,'Children');
% 
% set(gca,'Children',[h(1) h(5) h(6) h(7) h(8) h(9)  h(2) h(3) h(4)])
hold on
ytemp = linspace(p4.YLim(1),p4.YLim(end),100);
stlevel_prior1 = plot(normpdf(ytemp,data_mjp.params.kappa,(0.1)),ytemp,'linestyle','-','color','m','linewidth',2)
t_5     = title('(b2)');
t_5.Position = [0.250008259500775,1.51744923857868,0];

hold off

xticks(baseline5); xticklabels({'1.1'}); % Graph number on x axis at baseline (0)

box off

Y=gca; Y.YAxis.Visible='off';
% t_4.Position = [0.92394292522522,7.523961229566391,0];
p4p=p4.Position; p5p=p5.Position;
p5p(1)=p4p(1)+p4p(3)+.01; p5.Position=p5p; % Move subplot so they touch
p5.YLim = p4.YLim ;
%% Emission rate for state 1-Data set (2)

p6 = subplot(2,3,6)

baseline6 = 0;

h6 = histogram(P_mjp_3(2,:),30,'normalization','pdf','Orientation','horizontal','Facealpha',0.5,'FaceColor',color_sty(3,:));

for l =2
      f_hmm_2  =  patch(    [0 max([ max(h6.Values)])+0.5 max([max(h6.Values) ])+0.5 0],[P12_quant_3(l) P12_quant_3(l) P12_quant_3(end-l+1) P12_quant_3(end-l+1)],...
    get(h2(1),'FaceColor'),'FaceAlpha',0.2);
    
    set(f_hmm_2,'edgecolor','none')  %h(4)
end

l2          = line(get(gca,'XLim'),abs(true_P(1)).*[1 1],'linestyle',':','color','g','linewidth',2) %h(3)
hold on
ytemp = linspace(p4.YLim(1),p4.YLim(end),100);
stlevel_prior1 = plot(normpdf(ytemp,data_mjp.params.kappa,(0.1)),ytemp,'linestyle','-','color','m','linewidth',2)
xticks(baseline6); xticklabels({'1.3'}); % Graph number on x axis at baseline
box off;
Y=gca; Y.YAxis.Visible='off';
t_6     = title('(c2)');
t_6.Position = [0.250012261526925,1.51744923857868,0];
p5p = p5.Position; p6p = p6.Position;
p6p(1) = p5p(1)+p5p(3)+.01; p6.Position = p6p; % Move subplot so they touch
p6.YLim = p4.YLim;

linkaxes([p4 p5 p6],'y')
end