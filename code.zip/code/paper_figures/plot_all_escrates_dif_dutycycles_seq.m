function plot_all_escrates_dif_dutycycles_seq(tag)

addpath('fig')

figure('Units','inch','Position',[0 0 7.3 4])

 
set(gcf,'color','w')
clf
movegui(gcf,'center')



if isempty(tag)
    
tag = 100;
else
switch tag
    

        case 100

        data_mjp   = load('/Users/zelihakilic/Dropbox (ASU)/zeliha_presselab/Project2_MJP/manuscript_figures_2states/HMM_MJP_both_work/MJP_tag_51_new.mat');
        data_mjp_2 = load('/Users/zelihakilic/Dropbox (ASU)/zeliha_presselab/Project2_MJP/project2_revision/data/MJP_tag_501.mat');
        data_mjp_3 = load('/Users/zelihakilic/Dropbox (ASU)/zeliha_presselab/Project2_MJP/project2_revision/data/MJP_tag_502.mat');


        raw_data   = load('/Users/zelihakilic/Dropbox (ASU)/zeliha_presselab/Project2_MJP/manuscript_figures_2states/HMM_MJP_both_work/sim_tag_51.mat');
        raw_data_2 = load('/Users/zelihakilic/Dropbox (ASU)/zeliha_presselab/Project2_MJP/project2_revision/simulated_tag_501_prec_5.mat');
        raw_data_3 = load('/Users/zelihakilic/Dropbox (ASU)/zeliha_presselab/Project2_MJP/project2_revision/simulated_tag_501_prec_3.3333.mat');
        
%         gen_lim  = linspace(0,1,200); 
        ep_s = 0.02;
        
end
%% Visualizing escape rates and Mean Dwell Times
data_mjp = data_mjp.chain ;

s_1        = size(data_mjp.P);
s_2        = size(data_mjp_2.P);
s_3        = size(data_mjp_3.P);

burnin   = 2000;

quant_enu = 19;

quant_val = linspace(0,1,2*quant_enu +3);  

d_sample  = 1;

idx       = (burnin:d_sample:s_1(3));
idx_2       = (burnin:d_sample:s_2(3));
idx_3       = (burnin:d_sample:s_3(3));

bin_c     = 20;

%% -----------------------------MJP DATA_SECTION 1----------------------------------

P_mjp     = squeeze(nan(data_mjp.params.M,data_mjp.params.M,length(idx)));

for j=1:length(idx)   
    
P_mjp(:,:,j) = abs( squeeze(data_mjp.Q(:,:,idx(j))) ) ;

end


P11_quant    = quantile(P_mjp(1,1,:),quant_val);

P12_quant    = quantile(P_mjp(1,2,:),quant_val);


P21_quant    = quantile(P_mjp(2,1,:),quant_val);

P22_quant    = quantile(P_mjp(2,2,:),quant_val);

%% -----------------------------MJP DATA_SECTION 2----------------------------------


P_mjp_2     = squeeze(nan(data_mjp_2.params.M,data_mjp_2.params.M,length(idx_2)));

for j=1:length(idx_2)   
    
P_mjp_2(:,:,j) = abs( squeeze(data_mjp_2.Q(:,:,idx_2(j))) ) ;

end


P11_quant_2    = quantile(P_mjp_2(1,1,:),quant_val);

P12_quant_2    = quantile(P_mjp_2(1,2,:),quant_val);


P21_quant_2    = quantile(P_mjp_2(2,1,:),quant_val);

P22_quant_2    = quantile(P_mjp_2(2,2,:),quant_val);


%% -----------------------------MJP DATA_SECTION 3----------------------------------


P_mjp_3     = squeeze(nan(data_mjp_3.params.M,data_mjp_3.params.M,length(idx_3)));

for j=1:length(idx_3)   
    
P_mjp_3(:,:,j) = abs( squeeze(data_mjp_3.Q(:,:,idx_3(j))) ) ;

end


P11_quant_3    = quantile(P_mjp_3(1,1,:),quant_val);

P12_quant_3    = quantile(P_mjp_3(1,2,:),quant_val);


P21_quant_3    = quantile(P_mjp_3(2,1,:),quant_val);

P22_quant_3    = quantile(P_mjp_3(2,2,:),quant_val);


%% ---------------------------MJP DATA------------------------------------

burnin       = 5000;

quant_enu    = 19;

quant_val    = linspace(0,1,2*quant_enu +3);  

d_sample     = 1;

bin_c        = 40;

%% True Transition Probability Matrix

% true_P = expm(raw_data.ground.Q*(raw_data.observation.t_left(2)-raw_data.observation.t_left(1)));
true_Q = raw_data.ground.Q;

%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Escape for state 1-Data set (1)

p5 = subplot(2,3,1)
p5.OuterPosition = [0.044448669201521,0.526545542805473,0.30174827620393,0.389589532240494];
baseline5 = 0;

color_sty  = winter(8);
% axes11.OuterPosition = [0.070114073462584,0.655330882352941,0.401460383276518,0.24423810660665];
h5     = histogram(P_mjp(1,1,:),15,'normalization','pdf','Orientation','horizontal','FaceColor',color_sty(3,:));%h(1)'FaceColor',[0.9100    0.4100    0.1700]
hold on
for l =2
      f_hmm_5  =  patch(      [0 max([max(h5.Values)])+0.05 max([max(h5.Values)])+0.05 0],[P11_quant(l) P11_quant(l) P11_quant(end-l+1) P11_quant(end-l+1)],...
get(h5(1),'FaceColor'),'FaceAlpha',0.2);
    
      set(f_hmm_5,'edgecolor','none')  %h(4)
end

xLim        = p5.XLim;

l2          = line(get(gca,'XLim'),abs(true_Q(1,1)).*[1 1],'linestyle',':','color','g','linewidth',2) %h(3)

ytemp = linspace(1,70,100);
esc_rate_prior1 = plot(gampdf(ytemp,data_mjp.params.eta/2,1/(data_mjp.params.eta*data_mjp.params.beta)),ytemp,'linestyle','-','color','m','linewidth',2)

t_5     = title('(a1)');
t_5.Position = [0.018338503991801,40.55859375000001,0];
ylabel('\lambda_{\sigma_1} (s^{-1})')


hold off

xticks(baseline5); xticklabels({'0.75'}); % Graph number on x axis at baseline (0)

box off
p5.YLim = [1 40];



%% Emission rate for state 1-Data set (2)

p6 = subplot(2,3,2)
p6.OuterPosition = [0.32393811645059,0.526545542805473,0.245443633039855,0.389589532240494];

baseline6 = 0;

h6 = histogram(P_mjp_2(2,2,:),15,'normalization','pdf','Orientation','horizontal','FaceColor',color_sty(3,:));

for l =2
      f_hmm_2  =  patch(    [0 max([ max(h6.Values)])+0.05 max([max(h6.Values) ])+0.05 0],[P21_quant_2(l) P21_quant_2(l) P21_quant_2(end-l+1) P21_quant_2(end-l+1)],...
    get(h6(1),'FaceColor'),'FaceAlpha',0.2);
    
    set(f_hmm_2,'edgecolor','none')  %h(4)
end

l2          = line(get(gca,'XLim'),abs(true_Q(1,1)).*[1 1],'linestyle',':','color','g','linewidth',2) %h(3)
hold on
ytemp = linspace(1,70,100);
esc_rate_prior1 = plot(gampdf(ytemp,data_mjp.params.eta/2,1/(data_mjp.params.eta*data_mjp.params.beta)),ytemp,'linestyle','-','color','m','linewidth',2)

xticks(baseline6); xticklabels({'1.1'}); % Graph number on x axis at baseline
box off;
Y=gca; Y.YAxis.Visible='off';
t_6     = title('(b1)');
t_6.Position = [0.016071843036585,40.94035532994923,1.4e-14];

p5p=p5.Position; p6p=p6.Position;
p6p(1)=p5p(1)+p5p(3)+.01; p6.Position=p6p; % Move subplot so they touch
p6.YLim = [1 40];

%% Emission rate for state 1-Data set (3)

p7 = subplot(2,3,3)
p7.OuterPosition = [0.54734391355204,0.526545542805473,0.26675729199168,0.389589532240494];

baseline7 = 0;

h7 = histogram(P_mjp_3(2,2,:),20,'normalization','pdf','Orientation','horizontal','FaceColor',color_sty(3,:));
 
for l =2
      f_hmm_7  =  patch([0 max([max(h7.Values)])+0.01 max([max(h7.Values)])+0.01 0],[P21_quant_3(l) P21_quant_3(l) P21_quant_3(end-l+1) P21_quant_3(end-l+1)],...
          get(h7(1),'FaceColor'),'FaceAlpha',0.2);
    
      set(f_hmm_7,'edgecolor','none')  %h(4)
end

l2          = line(get(gca,'XLim'),abs(true_Q(1,1)).*[1 1],'linestyle',':','color','g','linewidth',2) %h(3)
hold on
ytemp = linspace(1,70,100);
esc_rate_prior1 = plot(gampdf(ytemp,data_mjp.params.eta/2,1/(data_mjp.params.eta*data_mjp.params.beta)),ytemp,'linestyle','-','color','m','linewidth',2)

xticks(baseline7); xticklabels({'1.3'}); % Graph number on x axis at baseline
box off;
Y=gca; Y.YAxis.Visible='off';
t_7     = title('(c1)');
t_7.Position = [0.016072043137892,40.94035532994923,1.4e-14];

p6p=p6.Position; p7p=p7.Position;
p7p(1)=p6p(1)+p6p(3)+.01; p7.Position=p7p; % Move subplot so they touch
p7.YLim = [1 40]

linkaxes([p5 p6 p7],'y')
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Emission rate for state 1-Data set (1)
p1 = subplot(2,3,4)

baseline1 = 0;

color_sty  = winter(8);
% axes11.OuterPosition = [0.070114073462584,0.655330882352941,0.401460383276518,0.24423810660665];
h1     = histogram(P_mjp(2,2,:),20,'normalization','pdf','Orientation','horizontal','FaceColor',color_sty(3,:));%h(1)'FaceColor',[0.9100    0.4100    0.1700]
hold on
for l =2
      f_hmm_1  =  patch(      [0 max([max(h1.Values)])+.01 max([max(h1.Values)])+.01 0],[P22_quant(l) P22_quant(l) P22_quant(end-l+1) P22_quant(end-l+1)],...
get(h1(1),'FaceColor'),'FaceAlpha',0.2);
    
      set(f_hmm_1,'edgecolor','none')  %h(4)
end

hold on
l2          = line(get(gca,'XLim'),abs(true_Q(2,2)).*[1 1],'linestyle',':','color','g','linewidth',2);

ytemp = linspace(1,90,100);
esc_rate_prior1 = plot(gampdf(ytemp,data_mjp.params.eta/2,1/(data_mjp.params.eta*data_mjp.params.beta)),ytemp,'linestyle','-','color','m','linewidth',2)

leg = legend('HMJP post. prob. distr.','95% conf. int.','True rate','Prior distr.')   

leg.Location    = 'southoutside';

leg.Orientation = 'horizontal';

leg.Position    = [0.119243774370736,0.967043415982775,0.748098859315589,0.033039647577092];

leg.NumColumns = 4;

legend boxoff;
l2          = line(get(gca,'XLim'),abs(true_Q(2,2)).*[1 1],'linestyle',':','color','g','linewidth',2);

ytemp = linspace(1,90,100);
esc_rate_prior1 = plot(gampdf(ytemp,data_mjp.params.eta/2,1/(data_mjp.params.eta*data_mjp.params.beta)),ytemp,'linestyle','-','color','m','linewidth',2)

leg = legend('HMJP post. prob. distr.','95% conf. int.','True rate','Prior distr.')   

leg.Location    = 'southoutside';

leg.Orientation = 'horizontal';

leg.Position    = [0.12116517073976,0.962638129778417,0.748098859315589,0.033039647577092];

leg.NumColumns = 4;

legend boxoff;

p1.YLim = [1 60];

xticks(baseline1); xticklabels({'0.75'}); % Graph number on x axis at baseline (0)
box off

t_1     = title('(a2)');
t_1.Position = [0.012053734064105,61.444036854906926,0];
ylabel('\lambda_{\sigma_2} (s^{-1})')

%% Emission rate for state 1-Data set (2)

p2 = subplot(2,3,5)

baseline2 = 0;

h2 =  histogram(P_mjp_2(1,1,:),20,'normalization','pdf','Orientation','horizontal','FaceColor',color_sty(3,:));

for l =2
      f_hmm_2  =  patch(    [0 max([ max(h2.Values)])+.01 max([max(h2.Values) ])+.01 0],[P11_quant_2(l) P11_quant_2(l) P11_quant_2(end-l+1) P11_quant_2(end-l+1)],...
    get(h2(1),'FaceColor'),'FaceAlpha',0.2);
    
    set(f_hmm_2,'edgecolor','none')  %h(4)
end

l2          = line(get(gca,'XLim'),abs(true_Q(2,2)).*[1 1],'linestyle',':','color','g','linewidth',2) %h(3)
ytemp = linspace(1,90,100);
hold on
esc_rate_prior1 = plot(gampdf(ytemp,data_mjp.params.eta/2,1/(data_mjp.params.eta*data_mjp.params.beta)),ytemp,'linestyle','-','color','m','linewidth',2)

xticks(baseline2); xticklabels({'1.1'}); % Graph number on x axis at baseline
box off;
t_2     = title('(b2)');
t_2.Position = [0.009533086421491,61.42258883248729,0];

Y=gca; Y.YAxis.Visible='off';

p1p=p1.Position; p2p=p2.Position;
p2p(1)=p1p(1)+p1p(3)+.01; p2.Position=p2p; % Move subplot so they touch
p2.YLim = [1 60];
xlabel('Post. prob. distr.')

%% Emission rate for state 1-Data set (3)

p3 = subplot(2,3,6)

baseline3 = 0;

h3 = histogram(P_mjp_3(1,1,:),20,'normalization','pdf','Orientation','horizontal','FaceColor',color_sty(3,:));
 
for l =2
      f_hmm_3  =  patch([0 max([max(h3.Values)])+.01 max([max(h3.Values)])+.01 0],[P11_quant_3(l) P11_quant_3(l) P11_quant_3(end-l+1) P11_quant_3(end-l+1)],...
          get(h3(1),'FaceColor'),'FaceAlpha',0.2);
    
      set(f_hmm_3,'edgecolor','none')  %h(4)
end

l2          = line(get(gca,'XLim'),abs(true_Q(2,2)).*[1 1],'linestyle',':','color','g','linewidth',2) %h(3)
t_3     = title('(c2)');
t_3.Position  =[0.008935474511872,61.42258883248729,0];
hold on
ytemp = linspace(1,90,100);
esc_rate_prior1 = plot(gampdf(ytemp,data_mjp.params.eta/2,1/(data_mjp.params.eta*data_mjp.params.beta)),ytemp,'linestyle','-','color','m','linewidth',2)

xticks(baseline3); xticklabels({'1.3'}); % Graph number on x axis at baseline
box off;
Y=gca; Y.YAxis.Visible='off';

p2p=p2.Position; p3p=p3.Position;
p3p(1)=p2p(1)+p2p(3)+.01; p3.Position=p3p; % Move subplot so they touch
p3.YLim = [1 60];

linkaxes([p1 p2 p3],'y')
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%



end